"""
Central configuration for the face-recognition + liveness system.
Keeping every tunable value here (instead of scattered through the code)
makes it easy to recalibrate when you move from your laptop webcam to the
Raspberry Pi camera, or when lighting conditions change.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------
# Paths
# ------------------------------------------------------------------
YOLO_MODEL_PATH = os.path.join(BASE_DIR, "best.pt")

# NOTE: this folder is spelled "Known_faces" (capital K) in this project.
# The previous version of the script looked for "known_faces" (lowercase),
# which works by accident on Windows (case-insensitive filesystem) but
# silently fails on Linux / Raspberry Pi OS (case-sensitive filesystem) -
# that mismatch was the "no known faces found" bug. Fixed here.
KNOWN_FACES_DIR = os.path.join(BASE_DIR, "Known_faces")

# ------------------------------------------------------------------
# Camera
# ------------------------------------------------------------------
# "auto" (default): camera_stream.py uses the Raspberry Pi CSI camera via
# Picamera2 automatically whenever the picamera2 package is installed, and
# only falls back to a plain USB/laptop webcam (index 0) when it isn't.
# This matters because on Raspberry Pi OS, cv2.VideoCapture(0) can appear
# to open successfully (isOpened() == True) but then fail on every read()
# call ("Could not read frame") - the CSI camera's sensor/ISP pipeline is
# only usable through libcamera/Picamera2, not OpenCV's V4L2 backend. With
# "auto" you do not need to remember any command-line flag on the Pi.
#
# Other values you can set here (or pass via --source):
#   0, 1, ...      - force a specific USB/laptop webcam index
#   "picamera2"    - force the Pi CSI camera (errors clearly if picamera2
#                    isn't installed, instead of silently trying a webcam)
#   "video.mp4"    - a video file, for testing without a camera
CAMERA_SOURCE = "auto"

FRAME_WIDTH = 640
FRAME_HEIGHT = 480

# ------------------------------------------------------------------
# Picamera2 (Raspberry Pi CSI camera) tuning - see camera_stream.py
# ------------------------------------------------------------------
# Seconds to sleep after picam2.start() before the first read, so AE/AWB
# settle. The engineer's reference Picamera2.py uses 0.3s; raised here
# because some camera modules/kernel versions need longer.
PICAMERA2_WARMUP_SECONDS = 1.0

# Extra frames captured-and-discarded right after start(), on top of the
# warm-up sleep above. Guards against the first capture_array() call
# occasionally failing or returning an unsettled frame on some hardware.
PICAMERA2_WARMUP_FRAMES = 2

# How many times to retry a failed capture_array() inside camera.read()
# before reporting the frame as unreadable.
PICAMERA2_READ_RETRIES = 3

# Picamera2 -> RGB, OpenCV/YOLO/InsightFace -> BGR, so camera_stream.py
# converts every frame with cv2.cvtColor(frame, cv2.COLOR_RGB2BGR) by
# default (matching the engineer's Picamera2.py). On a small number of
# libcamera versions/camera modules, "RGB888" is documented to already
# come out BGR-ordered - if faces/frames look color-swapped (blue skin
# tones) on your specific Pi, set this to False to skip the conversion.
PICAMERA2_SWAP_RB = True

# ------------------------------------------------------------------
# Face detection (YOLO)
# ------------------------------------------------------------------
YOLO_CONF_THRESHOLD = 0.50

# ------------------------------------------------------------------
# Face recognition (InsightFace embeddings)
# ------------------------------------------------------------------
RECOGNITION_SIMILARITY_THRESHOLD = 0.45

# ------------------------------------------------------------------
# Liveness / anti-spoofing
# ------------------------------------------------------------------
# How many recent frames of evidence to keep per tracked face.
LIVENESS_HISTORY_LEN = 20

# Minimum frames of evidence collected before we commit to a REAL/FAKE
# verdict (before that, the UI shows "ANALYZING..."). Lower = faster but
# noisier decisions; higher = slower but more stable decisions.
LIVENESS_MIN_FRAMES = 6

# Average liveness score (0..1) needed to call a face REAL.
# Start here, then recalibrate using tools/calibrate_liveness.py on your
# own camera + real faces + a printed photo + a phone screen.
LIVENESS_SCORE_THRESHOLD = 0.55

# ------------------------------------------------------------------
# Display-device ("is the face on a screen?") detection
# ------------------------------------------------------------------
# See liveness/screen_object.py. These control the detector that catches
# the main attendance fraud: an employee holding up a colleague's photo
# on a phone/tablet, a printed photo, or a playing video.

# How far around the face to look for the edges of a device, as a
# multiple of the face box. Bigger = catches devices held further back,
# but costs a little more per frame and picks up more room clutter.
SCREEN_SEARCH_MARGIN = 2.6

# Confidence (0..1) the geometric bezel detector must reach to call it a
# device. Lower it if real phone attempts slip through; raise it if
# real employees standing in front of a doorway/monitor get flagged.
SCREEN_BEZEL_CONFIDENCE = 0.55

# Confidence for the close-range fallback (flat lit panel / glass glare
# around the face, used when the device edges are out of frame).
SCREEN_PANEL_CONFIDENCE = 0.62

# A device must be seen in at least this fraction of the recent frames
# of a tracked face before it forces a FAKE verdict. Stops a hand or a
# single noisy frame from locking out a real employee.
SCREEN_VETO_RATIO = 0.40
SCREEN_VETO_MIN_FRAMES = 3

# ...unless a single detection is this confident (e.g. the COCO model
# explicitly labelling a cell phone around the face), which is refused
# immediately.
SCREEN_INSTANT_VETO_CONFIDENCE = 0.80

# Optional second YOLO model - a standard COCO-pretrained one that knows
# the classes "cell phone", "laptop", "tv", "book". This is the single
# most explainable spoof signal ("the face is inside a cell phone"), but
# it is OPTIONAL: if the weights are missing the system logs one warning
# and continues on the geometric detectors alone.
# ultralytics downloads yolov8n.pt automatically on a machine with
# internet; on an offline Raspberry Pi, copy the file next to this one.
USE_COCO_DEVICE_DETECTOR = True
COCO_MODEL_PATH = os.path.join(BASE_DIR, "yolov8n.pt")
COCO_CONF_THRESHOLD = 0.35
# How much of the face box must lie inside the device box before it
# counts. A phone in someone's hand at their side is not a spoof.
COCO_CONTAINMENT_MIN = 0.70

# ------------------------------------------------------------------
# ACTIVE liveness - the person must blink and move (liveness/active.py)
# ------------------------------------------------------------------
# This is the hard gate on attendance: no blink + no real 3D head
# movement = no check-in, no matter how good the image looks.
ACTIVE_LIVENESS_REQUIRED = True

# How many completed blinks are required. 1 is enough for most offices
# (people blink every 2-6 seconds without trying); raise to 2 for a
# stricter door.
REQUIRED_BLINKS = 1

# How long the person has to satisfy the check before it restarts and
# re-prompts. Not a lockout - just a fresh attempt.
ACTIVE_WINDOW_SECONDS = 12.0

# Blink state machine. Openness is eye height / eye width, so these are
# ratios of the person's own baseline, not absolute pixel values.
BLINK_CLOSE_RATIO = 0.62        # below baseline * this = eyes closing
BLINK_REOPEN_RATIO = 0.80       # above baseline * this = eyes open again
BLINK_MIN_CLOSED_FRAMES = 1     # shorter = detector noise, not a blink
BLINK_MAX_CLOSED_FRAMES = 12    # longer = eyes held shut / bad landmarks
BLINK_MIN_BASELINE_SAMPLES = 6  # frames needed to learn this person's open level
# The open-eye baseline is this percentile of recent openness values, not
# the median: someone may be mid-blink when the camera first sees them,
# and a median of those frames would settle near the CLOSED value, after
# which no blink is ever detected again - a silent fail-open.
BLINK_BASELINE_PERCENTILE = 75

# Frames of perfectly unchanging eye signal before we call it a still
# image. Real eyes are never this steady.
FROZEN_FRAMES_LIMIT = 25

# --- Non-rigid movement: beats a STILL IMAGE being moved --------------
# A still face on any flat surface (phone, tablet, monitor, print) moves
# as a plane - one affine transform explains all of it. A real 3D head
# does not. This is the leftover error after the best affine fit,
# normalized by how far things moved, so an attacker cannot improve
# their score by shaking the phone harder.
# It does NOT stop a video replay: a recorded video of a head turning
# reproduces real 3D motion. For that, rely on the device detection in
# liveness/screen_object.py and on CHALLENGE_MODE below.
# Measured on simulated landmark sequences with realistic detector
# jitter (tools/test_active_liveness.py reproduces this):
#   flat photo/screen waved, tilted, zoomed : 0.03 - 0.13
#   real head turning                       : 0.37 - 0.42
# 0.22 sits in the gap with margin on both sides. Re-measure on your own
# camera before trusting it - a low-frame-rate or soft-focus camera
# raises the flat number and narrows that gap.
MOVEMENT_NONRIGID_THRESHOLD = 0.22
MOVEMENT_HISTORY_FRAMES = 24
MOVEMENT_MIN_FRAME_GAP = 5      # compare frames this far apart
MOVEMENT_MIN_SHIFT = 0.020      # below this, nothing moved - don't score it
MOVEMENT_SMOOTH_WINDOW = 3      # frames averaged to kill landmark jitter
MOVEMENT_AGGREGATE_SAMPLES = 15 # residual samples the median is taken over

# --- Challenge mode (strongest, costs a few seconds) ------------------
# The device asks for randomly chosen actions at the moment of the
# attempt ("BLINK TWICE", "turn your head slightly left"). A pre-recorded
# video of a colleague cannot anticipate a prompt chosen at random. This
# is the ONLY setting here that genuinely defeats a prepared video, so
# turn it on if that is a real concern - the cost is a few seconds per
# check-in.
CHALLENGE_MODE = False
CHALLENGE_COUNT = 2             # how many actions to ask for
CHALLENGE_TIMEOUT_SECONDS = 8.0
CHALLENGE_YAW_RANGE = 0.10      # head-turn amount that counts as a turn
CHALLENGE_PITCH_RANGE = 0.08    # head-tilt amount that counts as a nod

# Mobile bursts: minimum usable frames before a blink/movement verdict is
# even attempted. Below this the API says "capture a longer burst"
# instead of guessing.
ACTIVE_BURST_MIN_FRAMES = 8

# ------------------------------------------------------------------
# Attendance database
# ------------------------------------------------------------------
ATTENDANCE_DB_PATH = os.path.join(BASE_DIR, "attendance.db")

# Consecutive frames a face must be BOTH recognized and verified live,
# with no device detected, before attendance is written. ~1 second at
# typical webcam speed - long enough that a momentary good frame on a
# spoof can never produce a check-in.
ATTENDANCE_CONFIRM_FRAMES = 12

# Save a JPEG of the moment of check-in (and of each refused attempt)
# next to the database, so every row can be audited against a picture.
SAVE_EVIDENCE_SNAPSHOTS = True
EVIDENCE_DIR = os.path.join(BASE_DIR, "evidence")

# ------------------------------------------------------------------
# Face tracker (keeps an identity for a face across frames so liveness
# signals like motion/blink can accumulate over time)
# ------------------------------------------------------------------
TRACKER_IOU_THRESHOLD = 0.3
TRACKER_MAX_MISSED = 10

# ------------------------------------------------------------------
# Mobile / single-burst check (see mobile_check.py)
# ------------------------------------------------------------------
# detect_webcam.py assumes a persistent video stream, which a phone
# client usually can't hand this system directly. Instead a mobile app
# captures a short burst of photos (e.g. 3-6 frames over ~1 second) and
# sends those. That burst is smaller than a live camera feed, so it gets
# its own (lower) minimum-frames requirement before committing to a
# verdict. Reuses the same score threshold as the live pipeline unless
# you find you need to recalibrate it separately for phone photos.
MOBILE_MIN_FRAMES = 3
MOBILE_LIVENESS_SCORE_THRESHOLD = LIVENESS_SCORE_THRESHOLD
