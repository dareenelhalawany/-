"""
Temporal (motion) liveness signal - compares two consecutive frames of the
SAME tracked face.

This is the main defense against someone holding up a PLAYING VIDEO of a
person's face on their phone (which would otherwise beat blink detection,
since the video shows a real person blinking). A phone/photo is a flat
rigid plane: whatever way it moves or shakes, every point on it moves
together, consistent with a single 2D affine transform. A real head is a
3D, slightly non-rigid object (independent small motion of eyes, mouth,
jaw, and parallax between nose/cheeks/ears) - its motion field does NOT
fit a single flat-plane transform as cleanly.

We estimate dense optical flow between frames, fit the best-possible
affine ("flat plane") model to it, and measure how much real motion is
left over (the residual). A very small residual = suspiciously flat.
"""

import cv2
import numpy as np


def planarity_penalty(prev_gray, curr_gray):
    """
    Returns a score in [0, 1]: 1.0 = motion looks non-planar/organic (more
    likely a real 3D head), 0.0 = motion fits a rigid flat plane almost
    perfectly (more likely a printed photo or a screen being held up).
    Returns None when there isn't enough signal to judge (first frame of
    a track, too little motion between frames, crop too small).
    """
    if prev_gray is None or curr_gray is None:
        return None

    if prev_gray.shape != curr_gray.shape:
        curr_gray = cv2.resize(curr_gray, (prev_gray.shape[1], prev_gray.shape[0]))

    if prev_gray.shape[0] < 24 or prev_gray.shape[1] < 24:
        return None

    flow = cv2.calcOpticalFlowFarneback(
        prev_gray, curr_gray, None,
        pyr_scale=0.5, levels=2, winsize=15,
        iterations=2, poly_n=5, poly_sigma=1.1, flags=0,
    )

    h, w = flow.shape[:2]
    ys, xs = np.mgrid[0:h, 0:w]
    pts = np.stack([xs.ravel(), ys.ravel()], axis=1).astype(np.float32)
    flow_flat = flow.reshape(-1, 2)

    motion_mag = np.linalg.norm(flow_flat, axis=1)
    # Too little motion between these two frames to say anything useful -
    # both a still real face and a still photo look "flat" when nothing
    # is moving, so we skip rather than falsely penalize.
    if motion_mag.mean() < 0.15:
        return None

    # Fit the best single affine ("flat plane") transform to the whole
    # flow field, then see how much motion it fails to explain.
    A = np.hstack([pts, np.ones((pts.shape[0], 1), dtype=np.float32)])
    try:
        sol_x, _, _, _ = np.linalg.lstsq(A, flow_flat[:, 0], rcond=None)
        sol_y, _, _, _ = np.linalg.lstsq(A, flow_flat[:, 1], rcond=None)
    except np.linalg.LinAlgError:
        return None

    pred_x = A @ sol_x
    pred_y = A @ sol_y
    residual = np.sqrt((flow_flat[:, 0] - pred_x) ** 2 + (flow_flat[:, 1] - pred_y) ** 2)

    residual_ratio = float(residual.mean()) / (float(motion_mag.mean()) + 1e-6)

    # Empirical reference - recalibrate with tools/calibrate_liveness.py.
    RESIDUAL_REF = 0.35
    return float(min(residual_ratio / RESIDUAL_REF, 1.0))
