"""
Lightweight IOU-based multi-face tracker.

Liveness cannot be judged reliably from a single frame alone (this is why
some naive "AI selfie liveness" demos are easy to fool). Several of the
strongest signals - is the face moving like a flat photo/screen or like a
real 3D head, is it blinking - only make sense once you can say "this is
the SAME face I was looking at 5 frames ago". That's what this tracker is
for: a minimal identity-across-frames mechanism, matched purely by
bounding-box overlap (IOU). It's intentionally simple - no Kalman filter,
no re-ID embeddings - which is enough for a single-camera access-control
scenario with at most a handful of faces in frame.
"""

import itertools
from collections import deque


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)

    inter_w = max(0, inter_x2 - inter_x1)
    inter_h = max(0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h

    area_a = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    area_b = max(0, bx2 - bx1) * max(0, by2 - by1)

    union = area_a + area_b - inter_area
    if union <= 0:
        return 0.0
    return inter_area / union


class Track:
    """State kept for a single face as it's followed across frames."""

    _id_counter = itertools.count(1)

    def __init__(self, box, history_len):
        self.id = next(Track._id_counter)
        self.box = box
        self.missed = 0

        # Rolling history of evidence used by LivenessDetector.
        self.gray_frames = deque(maxlen=history_len)
        self.eye_openness = deque(maxlen=history_len)
        self.liveness_scores = deque(maxlen=history_len)

        # Per-frame "was a phone/tablet/print detected around this face?"
        # history, filled by liveness/screen_object.py. Kept per track (not
        # per frame) so one unlucky frame can't veto a real employee, and
        # one unlucky frame can't let a phone through either.
        self.screen_flags = deque(maxlen=history_len)

        # Recognition + liveness results, refreshed every frame for display.
        self.name = "Unknown"
        self.verdict = "ANALYZING"   # ANALYZING / REAL / FAKE
        self.score = 0.0
        self.spoof_reason = ""       # plain-language why, when verdict == FAKE

        # Attendance bookkeeping (used by detect_webcam.py). A check-in
        # must survive several consecutive good frames before it's written
        # to the database, and each track may only ever write once.
        # Active blink/movement gate (liveness/active.py), created by the
        # caller on first sight of this face and kept for its lifetime -
        # the whole point is that evidence accumulates across frames.
        self.active_gate = None

        self.consecutive_ok = 0
        self.attendance_recorded = False
        self.attendance_message = ""
        self.spoof_logged = False


class FaceTracker:
    def __init__(self, iou_threshold=0.3, max_missed=10, history_len=20):
        self.iou_threshold = iou_threshold
        self.max_missed = max_missed
        self.history_len = history_len
        self.tracks = []

    def update(self, boxes):
        """
        boxes: list of (x1, y1, x2, y2) detections for the current frame.
        Returns a list of Track objects, aligned 1:1 with `boxes`
        (existing tracks are matched by best IOU; unmatched boxes get a
        brand new track).
        """
        assigned = []
        used_track_ids = set()

        for box in boxes:
            best_track = None
            best_iou = 0.0

            for track in self.tracks:
                if id(track) in used_track_ids:
                    continue
                score = iou(box, track.box)
                if score > best_iou:
                    best_iou = score
                    best_track = track

            if best_track is not None and best_iou >= self.iou_threshold:
                best_track.box = box
                best_track.missed = 0
                used_track_ids.add(id(best_track))
                assigned.append(best_track)
            else:
                new_track = Track(box, self.history_len)
                self.tracks.append(new_track)
                used_track_ids.add(id(new_track))
                assigned.append(new_track)

        # Age out tracks not matched this frame; drop them once they've
        # been missing too long (face left the frame).
        matched_ids = {id(t) for t in assigned}
        still_alive = []
        for track in self.tracks:
            if id(track) not in matched_ids:
                track.missed += 1
                if track.missed <= self.max_missed:
                    still_alive.append(track)
            else:
                still_alive.append(track)
        self.tracks = still_alive

        return assigned
