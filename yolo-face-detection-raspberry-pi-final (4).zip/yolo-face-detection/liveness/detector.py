"""
LivenessDetector - combines every signal in this package into a single
REAL / FAKE verdict per tracked face, accumulated over several frames.

Design notes
------------
This is a *passive* (no user challenge like "please blink now" or "turn
your head") anti-spoofing system, built entirely from classic image
processing - no extra neural network weights to download. That's a
deliberate choice here since it needs to work out of the box. It's a
solid baseline and will catch the common attacks (printed photo, phone
photo of a photo, phone video replay) reasonably well once calibrated to
your camera - but it is NOT as strong as a dedicated trained anti-spoofing
model (e.g. Silent-Face-Anti-Spoofing / MiniFASNet). If you want to
upgrade later, this module's `evaluate()` interface is the place to swap
in a model's prediction instead of / alongside the heuristic score - see
README.md -> "Upgrading to a trained anti-spoofing model".

Signal summary
--------------
- sharpness / texture_entropy / frequency / color: work on a SINGLE frame,
  and are the main defense against BOTH printed photos and phone/video
  replay (they look for recapture artifacts: blur, screen grid, halftone
  dots, glare).
- motion: needs 2+ frames of the SAME tracked face; catches a flat photo
  or phone being held up and moved/shaken (rigid planar motion) vs a real
  head's more complex motion.
- blink_bonus: needs several frames; catches a *static* printed photo
  specifically (never blinks). Does nothing against video replay (a video
  shows blinking too) - that's why it's weighted low.
- screen: comes from liveness/screen_object.py and answers a different
  question from all of the above - not "does this face look real?" but
  "is there a phone / tablet / laptop / printed photo physically around
  it?". Because that evidence is geometric rather than photometric, it
  survives the case that defeats the others: a very high-quality screen,
  well lit, held steady. It is therefore treated as a VETO, not just a
  weighted score - see `_screen_veto()` below.
"""

import cv2
import numpy as np

from . import blink, color, frequency, motion, texture

try:
    from config import (LIVENESS_MIN_FRAMES, LIVENESS_SCORE_THRESHOLD,
                        SCREEN_VETO_RATIO, SCREEN_VETO_MIN_FRAMES,
                        SCREEN_INSTANT_VETO_CONFIDENCE)
except ImportError:  # pragma: no cover - fallback if imported standalone
    LIVENESS_MIN_FRAMES = 6
    LIVENESS_SCORE_THRESHOLD = 0.55
    SCREEN_VETO_RATIO = 0.4
    SCREEN_VETO_MIN_FRAMES = 3
    SCREEN_INSTANT_VETO_CONFIDENCE = 0.80

WEIGHTS = {
    "sharpness": 0.12,
    "texture_entropy": 0.17,
    "frequency": 0.21,
    "color": 0.12,
    "motion": 0.13,
    "blink_bonus": 0.08,
    "screen": 0.17,
}


class LivenessDetector:
    def __init__(self, min_frames=LIVENESS_MIN_FRAMES,
                 score_threshold=LIVENESS_SCORE_THRESHOLD):
        self.min_frames = min_frames
        self.score_threshold = score_threshold

    def evaluate(self, track, face_crop, kps=None, screen_evidence=None):
        """
        Feed one frame of evidence for a tracked face.

        track: a liveness.tracker.Track instance (holds history for this
               specific face across frames).
        face_crop: BGR numpy array, the cropped face region for THIS frame.
        kps: optional, InsightFace face.kps (5-point landmarks, full-frame
             coords) for the blink signal.
        screen_evidence: optional dict from
             liveness.screen_object.evaluate_screen_evidence() - "is this
             face being displayed on a device?". Computed by the caller
             because it needs the FULL frame (the bezel is outside the
             face crop), which this method never sees.

        Returns (verdict, score, details):
            verdict: "ANALYZING" | "REAL" | "FAKE"
            score:   float 0..1, the running average liveness score
            details: dict of the individual per-frame signal values,
                     useful for debugging / on-screen overlay
        """
        gray = cv2.cvtColor(face_crop, cv2.COLOR_BGR2GRAY)

        s_sharp = texture.sharpness_score(face_crop)
        s_tex = texture.micro_texture_entropy(face_crop)
        s_freq = frequency.moire_and_grid_penalty(face_crop)
        s_color = color.color_naturalness_score(face_crop)

        prev_gray = track.gray_frames[-1] if track.gray_frames else None
        s_motion = motion.planarity_penalty(prev_gray, gray)

        track.gray_frames.append(gray)

        openness = None
        if kps is not None:
            openness = blink.eye_openness_from_kps(gray, kps, track.box)
        if openness is not None:
            track.eye_openness.append(openness)
        blink_bonus = 1.0 if blink.blink_detected(track.eye_openness) else 0.5

        # Screen/device evidence: 1.0 when nothing device-like is around
        # the face, dropping toward 0.0 as the evidence strengthens.
        screen_detected = bool(screen_evidence and screen_evidence.get("detected"))
        screen_conf = float(screen_evidence.get("confidence", 0.0)) if screen_evidence else 0.0
        s_screen = 1.0 - screen_conf if screen_detected else 1.0
        track.screen_flags.append(1 if screen_detected else 0)

        frame_score = (
            WEIGHTS["sharpness"] * s_sharp
            + WEIGHTS["texture_entropy"] * s_tex
            + WEIGHTS["frequency"] * s_freq
            + WEIGHTS["color"] * s_color
            + WEIGHTS["motion"] * (s_motion if s_motion is not None else 0.5)
            + WEIGHTS["blink_bonus"] * blink_bonus
            + WEIGHTS["screen"] * s_screen
        )
        frame_score = float(np.clip(frame_score, 0.0, 1.0))
        track.liveness_scores.append(frame_score)

        details = {
            "sharpness": round(s_sharp, 2),
            "texture": round(s_tex, 2),
            "frequency": round(s_freq, 2),
            "color": round(s_color, 2),
            "motion": None if s_motion is None else round(s_motion, 2),
            "blink_bonus": blink_bonus,
            "screen": round(s_screen, 2),
            "frame_score": round(frame_score, 2),
        }
        if screen_evidence and screen_evidence.get("source", "none") != "none":
            details["screen_src"] = screen_evidence["source"]

        # ------------------------------------------------------------------
        # Veto: a device seen around the face overrides a good average score.
        # ------------------------------------------------------------------
        veto_reason = self._screen_veto(track, screen_evidence)
        if veto_reason:
            track.verdict = "FAKE"
            track.spoof_reason = veto_reason
            track.score = float(np.mean(track.liveness_scores))
            details["veto"] = "screen"
            return track.verdict, track.score, details

        if len(track.liveness_scores) < self.min_frames:
            track.verdict = "ANALYZING"
            track.score = frame_score
            return track.verdict, track.score, details

        avg_score = float(np.mean(track.liveness_scores))
        track.verdict = "REAL" if avg_score >= self.score_threshold else "FAKE"
        track.score = avg_score
        if track.verdict == "FAKE":
            track.spoof_reason = (
                "Liveness signals (texture / frequency / motion) indicate a recaptured "
                f"image rather than a live face - score {avg_score:.2f} is below the "
                f"required {self.score_threshold:.2f}."
            )
        else:
            track.spoof_reason = ""
        return track.verdict, avg_score, details

    def _screen_veto(self, track, screen_evidence):
        """
        Decide whether display-device evidence alone should force FAKE.

        Requiring a RATIO of recent frames rather than a single hit is
        what keeps this usable in a real office: a hand passing through
        the shot or one bad Canny frame shouldn't lock a real employee
        out, but a phone is still a phone in frame after frame, so a
        genuine attack clears the ratio almost immediately.

        A single very high-confidence hit (e.g. the COCO detector
        outright labelling a cell phone around the face) is enough on its
        own - that one is not the kind of evidence that appears by
        accident.
        """
        if screen_evidence and screen_evidence.get("detected") and \
                screen_evidence.get("confidence", 0.0) >= SCREEN_INSTANT_VETO_CONFIDENCE:
            return screen_evidence.get("reason") or "A display device was detected around this face."

        flags = list(track.screen_flags)
        if len(flags) < SCREEN_VETO_MIN_FRAMES:
            return ""
        recent = flags[-max(SCREEN_VETO_MIN_FRAMES, self.min_frames):]
        if (sum(recent) / len(recent)) >= SCREEN_VETO_RATIO:
            if screen_evidence and screen_evidence.get("reason"):
                return screen_evidence["reason"]
            return (
                "A phone / tablet / monitor / printed photo was detected around this "
                "face across multiple frames - the face is being displayed on something, "
                "not standing in front of the camera."
            )
        return ""
