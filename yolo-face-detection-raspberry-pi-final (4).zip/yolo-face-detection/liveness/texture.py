"""
Texture-based liveness signals (work on a single frame - no tracking
needed). Real skin, photographed directly, retains fine detail: pores,
peach fuzz, subtle shading, small blemishes. A photo of a photo, or a
photo of a phone/monitor screen, has already been through one extra
capture-and-reproduce cycle and tends to lose that fine detail while
picking up artifacts of its own (paper fiber texture, screen sub-pixel
grid, halftone dots, an extra layer of JPEG/print compression blur).
"""

import cv2
import numpy as np


def sharpness_score(face_bgr):
    """
    Laplacian-variance sharpness. Low variance = blurry/flat = more likely
    a recaptured photo or a screen; high variance = crisp fine detail =
    more likely a real face directly in front of the camera.

    Returns a value roughly in [0, 1] (soft-capped).
    """
    gray = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2GRAY)
    lap_var = cv2.Laplacian(gray, cv2.CV_64F).var()

    # Empirical reference - recalibrate for your camera/lighting using
    # tools/calibrate_liveness.py.
    SHARPNESS_REF = 350.0
    return float(min(lap_var / SHARPNESS_REF, 1.0))


def micro_texture_entropy(face_bgr):
    """
    Local Binary Pattern (LBP) histogram entropy over the face crop.
    Real skin has rich, near-random micro-texture -> a high-entropy LBP
    histogram. Paper and LCD/phone screens have a more repetitive,
    uniform micro-structure once you're this close -> lower entropy.

    Returns a value in [0, 1].
    """
    gray = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, (96, 96)).astype(np.int16)

    h, w = gray.shape
    r = 1
    center = gray[r:h - r, r:w - r]
    code = np.zeros_like(center, dtype=np.uint8)

    offsets = [(-1, -1), (-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1)]
    for i, (dy, dx) in enumerate(offsets):
        neighbor = gray[r + dy: h - r + dy, r + dx: w - r + dx]
        code |= ((neighbor >= center).astype(np.uint8) << i)

    hist, _ = np.histogram(code, bins=256, range=(0, 256))
    hist = hist.astype(np.float64) / (hist.sum() + 1e-9)
    entropy = -np.sum(hist * np.log2(hist + 1e-12))

    # Max possible entropy for a 256-bin histogram is 8.0; real close-up
    # skin usually lands well above photos/screens.
    return float(min(entropy / 7.5, 1.0))
