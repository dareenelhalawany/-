"""
ACTIVE liveness - the person must actually DO something.

Everything in this package so far is *passive*: it looks at pixels and
judges whether they came from a live face. That is a good first line, but
it is a judgement about image quality, and image quality is exactly what
an attacker improves when they buy a better phone.

This module changes the question from "does this look live?" to:

    "Did a human blink, and did a three-dimensional head move, in the
     last few seconds - and, in challenge mode, did they do the specific
     thing this device asked for at random, one second ago?"

Why each part matters, and what it stops:

1. BLINK (BlinkDetector)
   A printed photo, a phone showing a still image, a face on paper: none
   of them ever blink. A real person blinks every 2-6 seconds without
   trying. This alone kills every static-image attack.
   It does NOT stop a video replay - a recorded video blinks too.

2. NON-RIGID MOVEMENT (MovementVerifier)
   This stops the STILL IMAGE being moved - the most common attempt by
   far, because it is the easiest one to make. A still face on any flat
   surface (a print, or a phone showing a photo) is a plane: however you
   wave, tilt, rotate or shake that plane, every landmark on it moves
   together, and one 2D affine matrix describes the whole thing. A real
   head is 3D - when it turns even slightly the nose swings across the
   face, one cheek compresses, the far eye moves closer to the nose. No
   single affine transform explains that.

   So: fit the best affine transform between an earlier frame's
   landmarks and the current frame's, and measure what is left over. A
   moved photo leaves almost nothing; a real head leaves a clear
   residual. The attacker cannot game this by waving the phone harder,
   because the residual is normalized by how far things moved.

   BE CLEAR ABOUT WHAT THIS DOES NOT DO: it does not stop a VIDEO
   REPLAY. A recorded video of a colleague turning their head, played on
   a phone, reproduces that genuine 3D motion faithfully - the landmarks
   on the screen move exactly as the real head's did. Non-rigid motion
   is a still-image defense, not a video defense. Video replay is
   handled by three other things in this project: the device/bezel
   detection in screen_object.py, the moire and texture signals in
   frequency.py / texture.py, and point 3 below.

3. CHALLENGE (ActiveLivenessGate, challenge mode)
   This is the only thing here that genuinely stops a prepared video,
   and it is the reason to turn CHALLENGE_MODE on if video replay is a
   real concern rather than a theoretical one. The device picks an
   action at random at the moment of the attempt and gives a few seconds
   to comply. A video recorded yesterday cannot know that "turn your
   head to the left" was going to be asked today. Nothing else in this
   file has that property. The cost is a couple of seconds of the
   employee's time.

All thresholds live in config.py and should be calibrated on the real
camera - see tools/test_active_liveness.py.
"""

import random
import time

import numpy as np

try:
    import config
    _CFG = config
except ImportError:  # pragma: no cover
    _CFG = None


def _cfg(attr, default):
    return getattr(_CFG, attr, default) if _CFG is not None else default


# ----------------------------------------------------------------------
# Landmark helpers
# ----------------------------------------------------------------------
# InsightFace's buffalo_l pack includes a 106-point 2D landmark model.
# In that layout the two eye contours are points 33-42 and 87-96. We do
# NOT rely on the exact ordering inside each cluster: the openness
# measure below uses the cluster's height-to-width extent, which gives
# the same answer whichever way round the points are indexed. That makes
# this robust to the variations between insightface releases, which is
# worth more here than a textbook eye-aspect-ratio.
EYE_CLUSTER_A = list(range(33, 43))
EYE_CLUSTER_B = list(range(87, 97))


def eye_openness_106(landmarks_106):
    """
    Openness = eye height / eye width, averaged over both eyes.

    Open eye ~0.25-0.40, closed eye ~0.02-0.10. Dividing by width makes
    it scale-free, so it does not change when the person steps closer to
    the camera - which a raw pixel height would, producing phantom
    "blinks" every time someone leans in.

    Returns a float, or None if the landmarks aren't usable.
    """
    if landmarks_106 is None or len(landmarks_106) < 97:
        return None

    points = np.asarray(landmarks_106, dtype=np.float32)
    ratios = []
    for cluster in (EYE_CLUSTER_A, EYE_CLUSTER_B):
        pts = points[cluster]
        width = float(pts[:, 0].max() - pts[:, 0].min())
        height = float(pts[:, 1].max() - pts[:, 1].min())
        if width < 1e-3:
            continue
        ratios.append(height / width)

    if not ratios:
        return None
    return float(np.mean(ratios))


def normalized_landmarks(points, box):
    """
    Put landmarks in a scale- and position-free frame so that walking
    toward the camera doesn't look like movement.
    """
    if points is None or len(points) < 3:
        return None
    pts = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    x1, y1, x2, y2 = box
    scale = max(1.0, float(max(x2 - x1, y2 - y1)))
    center = np.array([(x1 + x2) / 2.0, (y1 + y2) / 2.0], dtype=np.float32)
    return (pts - center) / scale


def pose_proxies(kps5):
    """
    Cheap yaw/pitch/roll proxies from the 5 InsightFace keypoints
    (left eye, right eye, nose, left mouth, right mouth).

    yaw  : nose displacement from the eye midpoint, along the eye axis,
           in units of inter-ocular distance. Negative = turned one way.
    pitch: nose height between the eye line and the mouth line, 0..1.
           Lower when the head tilts down (a nod).
    roll : angle of the eye line, degrees.

    These are approximations, not a calibrated head-pose model - they
    only need to be good enough to tell "clearly turned left" from
    "facing forward", which is all a challenge check asks of them.
    """
    if kps5 is None or len(kps5) < 5:
        return None

    pts = np.asarray(kps5, dtype=np.float32)
    left_eye, right_eye, nose, left_mouth, right_mouth = pts[:5]

    eye_vec = right_eye - left_eye
    interocular = float(np.linalg.norm(eye_vec))
    if interocular < 1e-3:
        return None

    eye_mid = (left_eye + right_eye) / 2.0
    mouth_mid = (left_mouth + right_mouth) / 2.0

    eye_axis = eye_vec / interocular
    yaw = float(np.dot(nose - eye_mid, eye_axis) / interocular)

    face_height = float(np.linalg.norm(mouth_mid - eye_mid))
    pitch = 0.5 if face_height < 1e-3 else float(
        np.linalg.norm(nose - eye_mid) / face_height
    )

    roll = float(np.degrees(np.arctan2(eye_vec[1], eye_vec[0])))
    return {"yaw": yaw, "pitch": pitch, "roll": roll, "interocular": interocular}


# ----------------------------------------------------------------------
# 1. Blink detection (event-based, not "bonus"-based)
# ----------------------------------------------------------------------
class BlinkDetector:
    """
    Counts completed blinks with an open -> closed -> open state machine.

    Two guards against false blinks:

    - A closure must last between MIN and MAX frames. A one-frame dip is
      detector noise; a closure lasting several seconds is someone with
      their eyes shut, or a bad landmark fit, not a blink.
    - The baseline "open" level is a rolling high percentile of recent
      frames, so it adapts to the person, their glasses and the lighting
      instead of relying on one global threshold that works for one face
      in one room. A percentile rather than a median specifically because
      the person may be mid-blink when the camera first sees them: a
      median of those first frames would settle near the CLOSED value and
      the detector would then never see another blink for the rest of the
      session - silently failing open, which is the worst way for a
      security check to fail.
    """

    def __init__(self):
        self.close_ratio = _cfg("BLINK_CLOSE_RATIO", 0.62)
        self.reopen_ratio = _cfg("BLINK_REOPEN_RATIO", 0.80)
        self.min_closed_frames = _cfg("BLINK_MIN_CLOSED_FRAMES", 1)
        self.max_closed_frames = _cfg("BLINK_MAX_CLOSED_FRAMES", 12)
        self.min_baseline_samples = _cfg("BLINK_MIN_BASELINE_SAMPLES", 6)
        self.baseline_percentile = _cfg("BLINK_BASELINE_PERCENTILE", 75)

        self.open_samples = []
        self.closed_frames = 0
        self.is_closed = False
        self.blink_count = 0
        self.blink_times = []
        self.last_openness = None
        self.baseline = None

    def update(self, openness, now=None):
        """
        Feed one frame's openness value. Returns True on the frame a
        blink COMPLETES (eyes reopened), False otherwise.
        """
        now = now if now is not None else time.time()
        if openness is None:
            return False

        self.last_openness = openness

        if self.baseline is None or len(self.open_samples) < self.min_baseline_samples:
            self.open_samples.append(openness)
            self.baseline = float(np.percentile(self.open_samples, self.baseline_percentile))
            return False

        closed_level = self.baseline * self.close_ratio
        reopen_level = self.baseline * self.reopen_ratio

        if not self.is_closed:
            if openness < closed_level:
                self.is_closed = True
                self.closed_frames = 1
            else:
                # Only genuinely-open frames update the baseline, so a
                # long closure can't drag the baseline down and make the
                # eyes look permanently "open" again.
                self.open_samples.append(openness)
                if len(self.open_samples) > 60:
                    self.open_samples.pop(0)
                self.baseline = float(np.percentile(self.open_samples, self.baseline_percentile))
            return False

        # Currently closed.
        if openness < reopen_level:
            self.closed_frames += 1
            if self.closed_frames > self.max_closed_frames:
                # Too long to be a blink - treat as a new resting state.
                self.is_closed = False
                self.closed_frames = 0
            return False

        # Reopened.
        completed = self.min_closed_frames <= self.closed_frames <= self.max_closed_frames
        self.is_closed = False
        self.closed_frames = 0
        if completed:
            self.blink_count += 1
            self.blink_times.append(now)
            return True
        return False

    def blinks_since(self, since_ts):
        return sum(1 for t in self.blink_times if t >= since_ts)

    def is_frozen(self, window=20, min_variation=0.012):
        """
        True when openness has barely changed over many frames - the
        signature of a still image. Real eyes are never this steady, even
        between blinks: they move, squint and shift constantly.
        """
        if len(self.open_samples) < window:
            return False
        recent = self.open_samples[-window:]
        return float(np.std(recent)) < min_variation


# ----------------------------------------------------------------------
# 2. Non-rigid (3D) movement verification
# ----------------------------------------------------------------------
class MovementVerifier:
    """
    Distinguishes "a real head moved" from "a flat picture was moved".

    Keeps a short history of normalized landmark sets. For a pair of
    frames it fits the best 2D affine transform from one to the other and
    reports the leftover error. Flat = tiny leftover. 3D = clear
    leftover. See the module docstring for why this is the signal that
    survives a good-quality video replay.
    """

    def __init__(self, history=None):
        self.history = history or _cfg("MOVEMENT_HISTORY_FRAMES", 24)
        self.min_gap = _cfg("MOVEMENT_MIN_FRAME_GAP", 5)
        self.min_shift = _cfg("MOVEMENT_MIN_SHIFT", 0.020)
        self.smooth_window = _cfg("MOVEMENT_SMOOTH_WINDOW", 3)
        self.aggregate_count = _cfg("MOVEMENT_AGGREGATE_SAMPLES", 15)
        self.samples = []          # list of (timestamp, smoothed normalized landmarks)
        self.raw = []              # pre-smoothing, for the moving average
        self.poses = []            # list of (timestamp, pose proxies)
        self.ratios = []           # residual ratios, aggregated robustly
        self.best_nonrigid = 0.0
        self.last_nonrigid = 0.0

    def update(self, landmarks, box, kps5=None, now=None):
        now = now if now is not None else time.time()

        pose = pose_proxies(kps5)
        if pose is not None:
            self.poses.append((now, pose))
            if len(self.poses) > self.history:
                self.poses.pop(0)

        norm = normalized_landmarks(landmarks, box)
        if norm is None:
            return self.last_nonrigid

        # Landmark detectors jitter by a pixel or so every frame, and that
        # jitter is non-rigid by nature - it would otherwise show up as
        # "real 3D movement" and let a waved photograph through. Averaging
        # over a short window costs a fraction of a second of latency and
        # removes most of it.
        self.raw.append(norm)
        if len(self.raw) > self.smooth_window:
            self.raw.pop(0)
        smoothed = np.mean(np.stack(self.raw), axis=0) if len(self.raw) > 1 else norm

        self.samples.append((now, smoothed))
        if len(self.samples) > self.history:
            self.samples.pop(0)

        self.last_nonrigid = self._nonrigid_against_history(smoothed)
        if self.last_nonrigid > 0.0:
            self.ratios.append(self.last_nonrigid)
            if len(self.ratios) > self.aggregate_count:
                self.ratios.pop(0)

        # Median, not max. A maximum over many frame pairs is a maximum
        # over noise too, so it climbs toward 1.0 for anything given
        # enough frames. The median only rises if the motion is
        # CONSISTENTLY non-planar, which is true of a turning head and
        # false of a photo being waved around.
        self.best_nonrigid = (float(np.median(self.ratios))
                              if len(self.ratios) >= 3 else 0.0)
        return self.last_nonrigid

    def _nonrigid_against_history(self, current):
        """
        Residual ratio of this frame against the best-separated earlier
        frame. Only frames with real movement between them are compared:
        if the head barely moved, the residual is all noise and means
        nothing, so scoring it would only add error.
        """
        candidates = (self.samples[:-self.min_gap]
                      if len(self.samples) > self.min_gap else [])
        best_shift = 0.0
        best_ratio = 0.0
        for _, past in candidates:
            if past.shape != current.shape:
                continue
            shift = float(np.mean(np.linalg.norm(current - past, axis=1)))
            if shift < self.min_shift:
                continue
            # Prefer the pair with the LARGEST genuine movement: the more
            # the face actually moved, the better the signal-to-noise of
            # the residual measured against it.
            if shift > best_shift:
                best_shift = shift
                best_ratio = self._affine_residual(past, current)
        return best_ratio

    @staticmethod
    def _affine_residual(src, dst):
        """
        Least-squares affine fit src -> dst; returns mean residual divided
        by the mean movement, so it measures the SHAPE of the motion, not
        its size. That normalization is what stops an attacker from
        gaming the number by simply waving the phone harder.
        """
        n = src.shape[0]
        A = np.hstack([src, np.ones((n, 1), dtype=np.float32)])
        try:
            sol, _, _, _ = np.linalg.lstsq(A, dst, rcond=None)
        except np.linalg.LinAlgError:
            return 0.0
        predicted = A @ sol
        residual = float(np.mean(np.linalg.norm(dst - predicted, axis=1)))
        movement = float(np.mean(np.linalg.norm(dst - src, axis=1)))
        if movement < 1e-6:
            return 0.0
        return residual / movement

    def pose_range(self, key, since_ts=None):
        values = [p[key] for t, p in self.poses if since_ts is None or t >= since_ts]
        if len(values) < 2:
            return 0.0
        return float(max(values) - min(values))

    def current_pose(self):
        return self.poses[-1][1] if self.poses else None

    def reset(self):
        self.samples.clear()
        self.raw.clear()
        self.ratios.clear()
        self.poses.clear()
        self.best_nonrigid = 0.0
        self.last_nonrigid = 0.0


# ----------------------------------------------------------------------
# 3. Challenges
# ----------------------------------------------------------------------
class Challenge:
    """One randomly chosen action the person must perform, with a deadline."""

    DEFINITIONS = {
        "blink": "Please BLINK",
        "blink_twice": "Please BLINK TWICE",
        "turn_left": "Please turn your head SLIGHTLY LEFT",
        "turn_right": "Please turn your head SLIGHTLY RIGHT",
        "nod": "Please NOD your head",
    }

    def __init__(self, kind, started_at, timeout):
        self.kind = kind
        self.prompt = self.DEFINITIONS[kind]
        self.started_at = started_at
        self.timeout = timeout
        self.satisfied = False

    def expired(self, now):
        return not self.satisfied and (now - self.started_at) > self.timeout

    def check(self, blink_detector, movement, now):
        """Returns True once this challenge has been performed."""
        if self.satisfied:
            return True

        if self.kind == "blink":
            self.satisfied = blink_detector.blinks_since(self.started_at) >= 1
        elif self.kind == "blink_twice":
            self.satisfied = blink_detector.blinks_since(self.started_at) >= 2
        elif self.kind in ("turn_left", "turn_right"):
            # Sign convention depends on which eye insightface lists
            # first and whether the camera image is mirrored, so accept
            # movement of the required MAGNITUDE in either direction and
            # rely on the non-rigid residual to prove it was a real 3D
            # turn rather than a tilted photo. Asking for a specific
            # direction that the device then scores backwards is a much
            # worse failure than accepting either.
            self.satisfied = (
                movement.pose_range("yaw", self.started_at) >= _cfg("CHALLENGE_YAW_RANGE", 0.10)
                and movement.best_nonrigid >= _cfg("MOVEMENT_NONRIGID_THRESHOLD", 0.16)
            )
        elif self.kind == "nod":
            self.satisfied = (
                movement.pose_range("pitch", self.started_at) >= _cfg("CHALLENGE_PITCH_RANGE", 0.08)
                and movement.best_nonrigid >= _cfg("MOVEMENT_NONRIGID_THRESHOLD", 0.16)
            )
        return self.satisfied


# ----------------------------------------------------------------------
# 4. The gate the attendance write must pass
# ----------------------------------------------------------------------
class ActiveLivenessGate:
    """
    Per-tracked-face state machine. `update()` every frame; attendance is
    only allowed to be written when `satisfied` is True.

    Two modes, both set in config.py:

    - CHALLENGE_MODE = False: the person must simply blink at least
      REQUIRED_BLINKS times AND produce non-rigid head movement, within
      ACTIVE_WINDOW_SECONDS. Nothing is asked of them out loud; most
      people satisfy this in 2-4 seconds just by standing there.
    - CHALLENGE_MODE = True: on top of that, the device issues randomly
      ordered prompts ("BLINK TWICE", "turn your head slightly left").
      Slower, and the strongest option, because a pre-recorded video
      cannot anticipate a prompt chosen at the moment of the attempt.
    """

    def __init__(self, challenge_mode=None):
        self.required_blinks = _cfg("REQUIRED_BLINKS", 1)
        self.window = _cfg("ACTIVE_WINDOW_SECONDS", 12.0)
        self.nonrigid_threshold = _cfg("MOVEMENT_NONRIGID_THRESHOLD", 0.16)
        self.challenge_mode = (_cfg("CHALLENGE_MODE", False)
                               if challenge_mode is None else challenge_mode)
        self.challenge_count = _cfg("CHALLENGE_COUNT", 2)
        self.challenge_timeout = _cfg("CHALLENGE_TIMEOUT_SECONDS", 8.0)

        self.blink = BlinkDetector()
        self.movement = MovementVerifier()

        self.started_at = time.time()
        self._anchored = False      # see the first-frame re-anchor in update()
        self.satisfied = False
        self.satisfied_at = None
        self.failure_reason = ""
        self.frozen_frames = 0

        self.challenges = []
        self.challenge_index = 0
        if self.challenge_mode:
            self._build_challenges()

    def _build_challenges(self):
        pool = ["blink", "blink_twice", "turn_left", "turn_right", "nod"]
        chosen = random.sample(pool, min(self.challenge_count, len(pool)))
        # Always include at least one blink challenge - it's the cheapest
        # action for the employee and the hardest thing for a still image
        # to fake.
        if not any(c.startswith("blink") for c in chosen):
            chosen[0] = "blink"
        now = time.time()
        self.challenges = [Challenge(chosen[0], now, self.challenge_timeout)]
        self._pending_kinds = chosen[1:]

    # ------------------------------------------------------------------
    def update(self, landmarks_106=None, kps5=None, box=None, now=None):
        """
        Feed one frame. Returns a status dict:

            satisfied : bool  - may attendance be written?
            prompt    : str   - what to show the person right now
            progress  : dict  - blinks, movement score, challenge state
            reason    : str   - why it isn't satisfied yet / why it failed
        """
        now = now if now is not None else time.time()

        # The window and every "since" comparison are measured against
        # `started_at`, which was set from the wall clock at construction.
        # A caller replaying a recorded sequence supplies its own clock,
        # and then every blink lands "before" the start and is silently
        # ignored - a fail-closed bug that is invisible in normal use and
        # breaks every offline test. Anchor to whatever clock the first
        # frame arrives on.
        if not self._anchored:
            self.started_at = now
            self._anchored = True
            # Challenges built in __init__ carry a construction-time
            # stamp. Left alone, their deadline starts ticking before the
            # person has even reached the camera, and (on a replayed
            # clock) every action they perform counts as happening
            # "before" the prompt and is discarded.
            for challenge in self.challenges:
                challenge.started_at = now

        openness = eye_openness_106(landmarks_106)
        self.blink.update(openness, now=now)

        if box is not None:
            source = landmarks_106 if landmarks_106 is not None else kps5
            self.movement.update(source, box, kps5=kps5, now=now)

        # A completely frozen eye signal means a still image is being
        # presented. Say so specifically instead of letting it time out
        # with a vague message - the employee deserves to know why.
        if self.blink.is_frozen():
            self.frozen_frames += 1
        else:
            self.frozen_frames = 0

        if self.satisfied:
            return self._status("Verified - hold still", "")

        if self.frozen_frames >= _cfg("FROZEN_FRAMES_LIMIT", 25):
            self.failure_reason = (
                "The eyes never change at all across several seconds - this is a still "
                "image (a photo or a paused screen), not a person."
            )
            return self._status("STILL IMAGE DETECTED", self.failure_reason)

        if self.challenge_mode:
            return self._update_challenges(now)
        return self._update_passive(now)

    # ------------------------------------------------------------------
    def _update_passive(self, now):
        blinks = self.blink.blinks_since(self.started_at)
        moved = self.movement.best_nonrigid >= self.nonrigid_threshold

        if blinks >= self.required_blinks and moved:
            self.satisfied = True
            self.satisfied_at = now
            return self._status("Verified live person", "")

        if (now - self.started_at) > self.window:
            missing = []
            if blinks < self.required_blinks:
                missing.append("no blink was seen")
            if not moved:
                missing.append("no three-dimensional head movement was seen "
                                "(the face moved like a flat surface)")
            self.failure_reason = (
                "Live-person check timed out: " + " and ".join(missing) + "."
            )
            # Restart rather than latch a failure: a real employee who
            # looked away mid-check should just get another go.
            self._restart(now)
            return self._status("Look at the camera and blink", self.failure_reason)

        need = []
        if blinks < self.required_blinks:
            need.append("blink")
        if not moved:
            need.append("move your head slightly")
        return self._status("Please " + " and ".join(need), "")

    def _update_challenges(self, now):
        current = self.challenges[self.challenge_index]
        current.check(self.blink, self.movement, now)

        if current.satisfied:
            if self._pending_kinds:
                self.challenges.append(
                    Challenge(self._pending_kinds.pop(0), now, self.challenge_timeout)
                )
                self.challenge_index += 1
                return self._status(self.challenges[self.challenge_index].prompt, "")

            # All challenges done - still require the physics to agree.
            if self.movement.best_nonrigid >= self.nonrigid_threshold:
                self.satisfied = True
                self.satisfied_at = now
                return self._status("Verified live person", "")

            self.failure_reason = (
                "The requested actions were performed, but the face moved like a flat "
                "surface (a screen or a printed photo tilted in front of the camera), "
                "not like a real head."
            )
            self._restart(now)
            return self._status("Please try again, facing the camera", self.failure_reason)

        if current.expired(now):
            self.failure_reason = (
                f"The requested action ('{current.prompt}') was not performed in time."
            )
            self._restart(now)
            return self._status("Live check restarted", self.failure_reason)

        return self._status(current.prompt, "")

    def _restart(self, now):
        self.started_at = now
        self._anchored = True
        self.blink = BlinkDetector()
        self.movement.reset()
        self.frozen_frames = 0
        self.challenge_index = 0
        if self.challenge_mode:
            self._build_challenges()

    def _status(self, prompt, reason):
        return {
            "satisfied": self.satisfied,
            "prompt": prompt,
            "reason": reason,
            "progress": {
                "blinks": self.blink.blinks_since(self.started_at),
                "required_blinks": self.required_blinks,
                "nonrigid": round(self.movement.best_nonrigid, 3),
                "nonrigid_required": self.nonrigid_threshold,
                "challenge": (self.challenges[self.challenge_index].kind
                              if self.challenge_mode and self.challenges else None),
            },
        }


# ----------------------------------------------------------------------
# Burst version, for the mobile path
# ----------------------------------------------------------------------
def verify_burst(frames_landmarks, boxes, kps_list, fps_hint=None):
    """
    Passive active-liveness check over a captured burst (mobile_check.py).

    frames_landmarks: list of 106-point arrays (or None per frame)
    boxes:            list of face boxes, same length
    kps_list:         list of 5-point arrays, same length

    A burst is not a live session: there is no way to issue a challenge
    and wait, so this can only do the passive half - was there a blink,
    and was the movement non-rigid. Returns a dict with `satisfied`,
    `blinks`, `nonrigid` and a `reason`. If the burst is too short to
    judge, `satisfied` is False and the reason says to capture a longer
    burst rather than pretending a verdict was reached.
    """
    gate = ActiveLivenessGate(challenge_mode=False)
    gate.window = float("inf")  # a burst has no wall-clock window

    interval = 1.0 / (fps_hint or 8.0)
    t0 = time.time()
    for i, (lm, box, kps) in enumerate(zip(frames_landmarks, boxes, kps_list)):
        gate.update(landmarks_106=lm, kps5=kps, box=box, now=t0 + i * interval)

    blinks = gate.blink.blink_count
    nonrigid = gate.movement.best_nonrigid
    enough_frames = len(frames_landmarks) >= _cfg("ACTIVE_BURST_MIN_FRAMES", 8)

    satisfied = (enough_frames
                 and blinks >= gate.required_blinks
                 and nonrigid >= gate.nonrigid_threshold)

    if satisfied:
        reason = ""
    elif not enough_frames:
        reason = (
            f"Only {len(frames_landmarks)} usable frames - too few to see a blink or "
            "real head movement. Capture a burst of at least "
            f"{_cfg('ACTIVE_BURST_MIN_FRAMES', 8)} frames over about 2 seconds."
        )
    else:
        missing = []
        if blinks < gate.required_blinks:
            missing.append("no blink")
        if nonrigid < gate.nonrigid_threshold:
            missing.append("no three-dimensional head movement (the face moved like a flat image)")
        reason = "Live-person check failed: " + " and ".join(missing) + "."

    return {
        "satisfied": satisfied,
        "blinks": blinks,
        "nonrigid": round(float(nonrigid), 3),
        "reason": reason,
    }
