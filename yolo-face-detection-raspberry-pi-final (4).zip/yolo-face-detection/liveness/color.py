"""
Color/reflection-based liveness signal (single frame).

- Printed photos are often flatter/less saturated than real skin under
  normal room lighting (ink + paper reduces dynamic range).
- Phone/monitor screens held up to the camera frequently produce a
  bright specular glare patch (the screen's own backlight reflecting
  back into the lens), which real skin essentially never does indoors.
"""

import cv2
import numpy as np


def color_naturalness_score(face_bgr):
    """Returns a score in [0, 1], higher = more natural / live-skin-like."""
    hsv = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2HSV)
    sat = hsv[:, :, 1].astype(np.float32)

    sat_std = float(sat.std())
    SAT_STD_REF = 28.0
    sat_score = min(sat_std / SAT_STD_REF, 1.0)

    gray = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2GRAY)
    glare_ratio = float(np.sum(gray > 245)) / gray.size
    glare_score = max(0.0, 1.0 - (glare_ratio / 0.03))

    return float(np.clip(0.6 * sat_score + 0.4 * glare_score, 0.0, 1.0))
