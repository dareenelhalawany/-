"""
Mobile / API-friendly access check.

detect_webcam.py assumes a persistent local video stream (a laptop/Pi
webcam feeding cv2.VideoCapture in a loop). A phone client usually can't
hand this system that - instead it captures a short burst of photos
(e.g. 3-6 frames over about a second) and sends those. This module wraps
the same recognition + liveness pipeline behind one function,
`check_access()`, built specifically for that use case, and returns one
explicit, unambiguous result.

The case this exists to get right: someone points their phone's camera
at a PRINTED PHOTO, or at ANOTHER PHONE showing a photo/video, of a real
employee from Known_faces/. Face recognition alone will happily match
that photo to the employee's name - that match is real, the *person in
front of the camera* is not. `check_access()` never reports that as a
successful check-in: `is_spoof_of_known_person` is set, `access_granted`
is False, and `message` says in plain language that this is a picture of
that person, not the person, and access is refused.

Usage as a library:

    from mobile_check import ModelBundle, check_access

    bundle = ModelBundle.load()          # loads YOLO + InsightFace + Known_faces once
    result = check_access(bundle, frames)  # frames: list of BGR numpy arrays (a burst)
    print(result["message"])
    if result["access_granted"]:
        ...

Usage from the command line, feeding it photo files (e.g. a short burst
exported from a phone, or several stills of the same attempt):

    python mobile_check.py photo1.jpg photo2.jpg photo3.jpg

Note: this reuses the SAME liveness signals as detect_webcam.py
(sharpness, texture entropy, frequency/moire, color, and - if 2+ frames
are given - motion planarity). It is not a separate model, and it
inherits the same limits described in README.md: a solid first line of
defense, not a trained anti-spoofing network.
"""

import argparse
import json
import sys

import cv2
import numpy as np
from insightface.app import FaceAnalysis
from ultralytics import YOLO

import config
from attendance import AttendanceDB
from detect_webcam import load_known_faces, recognize
from liveness import CocoDeviceDetector, LivenessDetector
from liveness.active import verify_burst
from liveness.screen_object import evaluate_screen_evidence
from liveness.tracker import Track


class ModelBundle:
    """Loads the YOLO / InsightFace models and the Known_faces gallery once.

    Reuse a single instance across requests (e.g. keep it in memory in a
    backend process) - loading the models fresh on every check is slow
    and unnecessary.
    """

    def __init__(self, yolo_model, face_app, known_embeddings, known_names,
                 coco_detector=None):
        self.yolo_model = yolo_model
        self.face_app = face_app
        self.known_embeddings = known_embeddings
        self.known_names = known_names
        self.coco_detector = coco_detector

    @classmethod
    def load(cls, use_coco=None):
        yolo_model = YOLO(config.YOLO_MODEL_PATH)
        face_app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
        face_app.prepare(ctx_id=0, det_size=(320, 320))
        known_embeddings, known_names = load_known_faces(face_app, config.KNOWN_FACES_DIR)

        coco_detector = None
        if use_coco is None:
            use_coco = config.USE_COCO_DEVICE_DETECTOR
        if use_coco:
            coco_detector = CocoDeviceDetector()
            if not coco_detector.available:
                print(f"NOTE: {coco_detector.load_error}")
                coco_detector = None

        return cls(yolo_model, face_app, known_embeddings, known_names, coco_detector)


def _largest_face_box(yolo_model, frame):
    """Returns (x1, y1, x2, y2) of the largest detected face box, or None.

    A mobile check-in is one person deliberately presenting their face,
    so if several faces show up in a frame (e.g. someone in the
    background) the largest / closest one is almost always the subject.
    """
    results = yolo_model.predict(source=frame, conf=config.YOLO_CONF_THRESHOLD, verbose=False)
    best_box = None
    best_area = 0
    for box in results[0].boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(frame.shape[1], x2)
        y2 = min(frame.shape[0], y2)
        if x2 - x1 < 10 or y2 - y1 < 10:
            continue
        area = (x2 - x1) * (y2 - y1)
        if area > best_area:
            best_area = area
            best_box = (x1, y1, x2, y2)
    return best_box


def check_access(bundle, frames, db=None, record=True):
    """
    bundle: a loaded ModelBundle.
    db    : optional AttendanceDB. When given and the check passes, the
            verified check-in is written here - and when it fails, the
            attempt is written to the spoof audit table instead. Pass
            record=False to evaluate without touching the database.
    frames: list of BGR numpy arrays - a short burst from the same
            attempt, ideally captured a few hundred ms apart so the
            motion signal has something to compare. A single frame
            works too (motion signal is simply skipped), but a burst
            of 3+ is recommended and is what MOBILE_MIN_FRAMES assumes.

    Returns a dict:
        name                    : recognized employee name, or "Unknown"
        recognized              : bool - name matched someone in Known_faces
        verdict                 : "REAL" | "FAKE" | "ANALYZING"
        liveness_score          : float 0..1
        is_spoof_of_known_person: bool - True exactly when a KNOWN employee's
                                   face was matched but the person in front
                                   of the camera is not actually them (a
                                   photo/screen of them was shown instead)
        access_granted          : bool - True only when recognized AND REAL
                                   AND no display device was detected
        device_detected         : bool - a phone/tablet/laptop/print was found
                                   around the face
        active_liveness         : dict - blink count, non-rigid movement score
                                   and why the blink/movement check passed
                                   or failed over this burst
        device_source           : str  - which detector said so
        spoof_reason            : str  - plain-language why it was refused
        message                 : human-readable summary, safe to show to
                                   an end user or log verbatim
        attendance              : dict | None - the database result, when a
                                   db was passed and the check passed
        no_face_detected        : bool - True if no face was found in any frame
    """
    if not frames:
        raise ValueError("check_access() needs at least one frame")

    min_frames = min(config.MOBILE_MIN_FRAMES, len(frames))
    liveness_detector = LivenessDetector(
        min_frames=min_frames,
        score_threshold=config.MOBILE_LIVENESS_SCORE_THRESHOLD,
    )
    track = Track(box=(0, 0, 0, 0), history_len=max(len(frames), 1))

    name = "Unknown"
    verdict = "ANALYZING"
    score = 0.0
    any_face_found = False
    screen_evidence = None
    strongest_device = None

    # Collected across the burst so the blink / non-rigid-movement check
    # has a sequence to work with. A single photo can never satisfy it -
    # which is correct: one photo of a person is exactly what an attacker
    # has, and exactly what a live person can trivially beat by sending
    # a two-second burst instead.
    burst_landmarks, burst_boxes, burst_kps = [], [], []

    for frame in frames:
        box = _largest_face_box(bundle.yolo_model, frame)
        if box is None:
            continue
        any_face_found = True

        x1, y1, x2, y2 = box
        face_crop = frame[y1:y2, x1:x2]
        if face_crop.size == 0:
            continue
        track.box = box

        name, kps, landmarks_106 = recognize(
            bundle.face_app, face_crop, bundle.known_embeddings, bundle.known_names
        )
        burst_landmarks.append(landmarks_106)
        burst_boxes.append((0, 0, face_crop.shape[1], face_crop.shape[0]))
        burst_kps.append(kps)

        # Is this face being displayed on a phone/tablet/print? Needs the
        # full frame - the device's edges are outside the face box.
        screen_evidence = evaluate_screen_evidence(
            frame, box, getattr(bundle, "coco_detector", None)
        )
        if screen_evidence.get("detected"):
            if strongest_device is None or \
                    screen_evidence["confidence"] > strongest_device["confidence"]:
                strongest_device = screen_evidence

        verdict, score, _details = liveness_detector.evaluate(
            track, face_crop, kps=kps, screen_evidence=screen_evidence
        )

    if not any_face_found:
        return {
            "name": "Unknown",
            "recognized": False,
            "verdict": "ANALYZING",
            "liveness_score": 0.0,
            "is_spoof_of_known_person": False,
            "access_granted": False,
            "device_detected": False,
            "device_source": "none",
            "spoof_reason": "",
            "attendance": None,
            "no_face_detected": True,
            "message": "No face detected in the submitted photo(s). Ask the person to face the camera directly with good lighting.",
        }

    device = strongest_device
    device_detected = device is not None
    recognized = name != "Unknown"
    is_spoof_of_known_person = recognized and verdict == "FAKE"

    active = verify_burst(burst_landmarks, burst_boxes, burst_kps)
    active_required = config.ACTIVE_LIVENESS_REQUIRED
    active_ok = active["satisfied"] or not active_required

    access_granted = (recognized and verdict == "REAL"
                      and not device_detected and active_ok)
    spoof_reason = (track.spoof_reason
                    or (device["reason"] if device_detected else "")
                    or (active["reason"] if not active["satisfied"] else ""))

    if verdict == "ANALYZING":
        message = (
            "Not enough clear evidence yet to confirm this is a live person. "
            "Capture a couple more photos (ideally a fraction of a second apart)."
        )
    elif is_spoof_of_known_person and device_detected:
        message = (
            f"SPOOF DETECTED: this matches employee '{name}', but a "
            f"{device['source'].replace('coco:', '')} was detected around the face - "
            f"someone is showing a picture/video of {name} instead of {name} being "
            f"present. {name} has NOT been marked as attending. Access DENIED."
        )
    elif is_spoof_of_known_person:
        message = (
            f"SPOOF DETECTED: this photo matches employee '{name}', but the liveness "
            f"check shows it is a picture of {name} (printed photo or a phone/screen "
            f"showing their photo) - NOT {name} presenting in person. This is not a "
            f"real human in front of the camera. {name} has NOT been marked as "
            "attending. Access DENIED."
        )
    elif recognized and verdict == "REAL" and device_detected:
        # The photometric signals were happy, but the geometry says the
        # face sits inside a device. Geometry wins - this is exactly the
        # high-quality-screen case the score alone is weakest against.
        message = (
            f"REFUSED: the face matches '{name}' and looked live, but it is inside a "
            f"detected {device['source'].replace('coco:', '')}. A picture of an employee "
            f"is not the employee. {name} has NOT been marked as attending."
        )
    elif recognized and verdict == "REAL" and not active_ok:
        message = (
            f"NOT CONFIRMED: the face matches '{name}' and the image looks live, but "
            f"{active['reason']} Nobody has been marked present. Ask the person to "
            "record a short burst while blinking and turning their head slightly."
        )
    elif recognized and verdict == "REAL":
        message = f"{name} verified as a live person. ACCESS GRANTED."
    elif not recognized and verdict == "REAL":
        message = "A live person was detected, but this face does not match any registered employee. Access DENIED."
    else:  # not recognized and FAKE
        message = "SPOOF DETECTED: not a live human, and no known employee match either. Access DENIED."

    attendance_result = None
    if db is not None and record:
        if access_granted:
            attendance_result = db.record_attendance(
                name=name, liveness_score=score, method="mobile"
            )
            message = f"{message} {attendance_result['message']}"
        elif verdict == "FAKE" or device_detected or not active_ok:
            db.log_spoof(
                claimed_name=name,
                reason=spoof_reason or "Liveness check failed.",
                detector=(device["source"] if device_detected
                          else ("liveness" if verdict == "FAKE" else "active_liveness")),
                liveness_score=score,
                method="mobile",
            )

    return {
        "name": name,
        "recognized": recognized,
        "verdict": verdict,
        "liveness_score": round(float(score), 3),
        "is_spoof_of_known_person": is_spoof_of_known_person,
        "access_granted": access_granted,
        "device_detected": device_detected,
        "device_source": device["source"] if device_detected else "none",
        "active_liveness": active,
        "spoof_reason": spoof_reason,
        "attendance": attendance_result,
        "no_face_detected": False,
        "message": message,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Run the mobile-style access check against a burst of saved photos."
    )
    parser.add_argument("images", nargs="+", help="One or more image files, in capture order.")
    parser.add_argument("--no-db", action="store_true",
                        help="Evaluate only; do not write to the attendance database.")
    args = parser.parse_args()

    frames = []
    for path in args.images:
        frame = cv2.imread(path)
        if frame is None:
            print(f"ERROR: could not read image: {path}", file=sys.stderr)
            sys.exit(1)
        frames.append(frame)

    print("Loading models (YOLO + InsightFace) and Known_faces gallery...")
    bundle = ModelBundle.load()

    db = None if args.no_db else AttendanceDB(config.ATTENDANCE_DB_PATH)
    result = check_access(bundle, frames, db=db)
    print(json.dumps(result, indent=2))
    print()
    print(result["message"])


if __name__ == "__main__":
    main()
