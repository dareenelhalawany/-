# Employee Face Recognition + Liveness Detection

Detects faces (YOLO), recognizes employees (InsightFace embeddings vs
`Known_faces/`), and now also decides whether the face in front of the
camera is a **REAL live person** or a **spoof** (printed photo, or a phone
showing a photo/video of that person).

## What this system does

1. YOLO (`best.pt`) finds faces, an IOU tracker keeps each one's identity
   across frames, InsightFace matches it against `Known_faces/`.
2. Liveness signals decide whether that face is a live human or a
   recapture (printed photo, phone screen, video replay).
3. **Display-device detection** asks whether the face is physically
   *inside* a phone / tablet / laptop / monitor / printed photo, and
   vetoes it if so.
4. **Active liveness** requires the person to blink and to move their
   head in a way a flat image cannot - optionally in response to random
   prompts they could not have pre-recorded.
5. **Only** a face that is recognized, live, device-free and past the
   blink/movement gate is written to the attendance database with name,
   date and time.
   Everything else goes to a separate spoof audit log and the employee
   stays marked absent.

## What changed from the previous version

1. **Bug fix**: the old code looked for a folder called `known_faces`
   (lowercase), but the actual folder is `Known_faces` (capital K). On
   Windows this worked by accident (case-insensitive filesystem); on
   Linux / Raspberry Pi OS it silently failed ("no known faces found").
   Fixed in `config.py`.
2. **New `liveness/` package**: a full anti-spoofing module (see below).
3. `detect_webcam.py` rewritten to track faces across frames (needed for
   liveness), and to only report "ACCESS OK" for a name when the face is
   both recognized **and** verdict == REAL.
4. All thresholds centralized in `config.py` so you can recalibrate for a
   new camera (like the Raspberry Pi camera) in one place.

## How the liveness detection works

This is a **passive** system - no "please blink" prompts - built from
several classic computer-vision signals, combined into one score per
tracked face:

| Signal | File | Catches |
|---|---|---|
| Sharpness (Laplacian variance) | `liveness/texture.py` | Blur from photo/screen recapture |
| Micro-texture entropy (LBP) | `liveness/texture.py` | Loss of fine skin detail |
| Frequency / Moire pattern | `liveness/frequency.py` | Screen pixel grid & print halftone dots - **the main defense against phone-screen video replay**, since it works on a single frame regardless of motion |
| Color naturalness / glare | `liveness/color.py` | Screen glare, flat print colors |
| Motion planarity (optical flow) | `liveness/motion.py` | A photo/phone held up and moved still moves as one flat rigid plane, unlike a real head |
| Blink detection | `liveness/blink.py` | A *static* printed photo never blinks (bonus signal only) |

Each tracked face accumulates evidence over `LIVENESS_MIN_FRAMES` frames
(`config.py`, default 6) before committing to a verdict, so you'll see
"Checking liveness..." briefly before REAL/FAKE is shown.

**Honesty about limits**: this is a heuristic system, not a trained
anti-spoofing neural network. It's a strong first line of defense and
good for a course/startup MVP, but a determined attacker with a
high-resolution screen and good lighting could still probe it. If you
need production-grade robustness later, see "Upgrading" below.

## Setup

```bash
pip install -r requirements.txt
```

`best.pt` (your trained YOLO face model) and `Known_faces/<person>/*.jpg`
must be present in the project folder, as before.

## Testing on your laptop webcam

```bash
python detect_webcam.py
```

- Green box = recognized employee, verdict REAL -> "ACCESS OK"
- Amber box = still collecting evidence ("Checking liveness...")
- Red box = **FAKE** verdict (spoof attempt) - shown in red even if a name
  was matched, and access must NOT be granted in that case
- Press `Q` to quit

Add `--show-debug` to see each signal's raw score printed under every
face - useful while calibrating:

```bash
python detect_webcam.py --show-debug
```

To test against a saved video file instead of a live camera (e.g. a
video of someone's face to confirm it gets flagged FAKE):

```bash
python detect_webcam.py --source path/to/video.mp4
```

### Quick calibration test set

Before trusting the thresholds, build 3 short clips/photos and try each:

1. Your own face, live, in front of the laptop webcam -> should settle on REAL
2. A printed photo of a face held up to the camera -> should settle on FAKE
3. A photo/video of a face playing on your phone, held up to the camera -> should settle on FAKE

If results are off, adjust `LIVENESS_SCORE_THRESHOLD` in `config.py`
(higher = stricter / more false rejections of real people; lower = looser
/ more spoofs let through), or tune the `*_REF` constants inside
`liveness/texture.py`, `frequency.py`, `motion.py` for your specific
camera and lighting.

You can also sanity-check individual signals on saved images, without
running the full camera pipeline:

```bash
python tools/test_liveness_on_images.py my_face.jpg printed_photo.jpg phone_screen.jpg
```

## Mobile check-in (phone shows a photo of an employee)

`detect_webcam.py` assumes a persistent local video stream, which a phone
client can't hand this system directly. For a mobile check-in flow, use
`mobile_check.py` instead: it takes a short burst of photos (3-6 frames
captured roughly a second, ideal for what a phone app would upload) and
returns one explicit result.

This is the scenario the whole liveness module exists for: someone points
a phone's camera at a **printed photo**, or at **another screen showing a
photo/video**, of a real employee from `Known_faces/`. Face recognition
alone will match that photo to the employee's name - that match is real,
but the person in front of the camera is not. `mobile_check.py` never
reports that as a successful check-in. It explicitly flags it as a spoof
of a known person and denies access, distinct from an unrecognized face
and from a live person who simply isn't in the database.

```bash
python mobile_check.py photo1.jpg photo2.jpg photo3.jpg
```

Example output when a phone/printed photo of a known employee is shown
instead of the employee themself:

```json
{
  "name": "Marwan",
  "recognized": true,
  "verdict": "FAKE",
  "liveness_score": 0.31,
  "is_spoof_of_known_person": true,
  "access_granted": false,
  "no_face_detected": false,
  "message": "SPOOF DETECTED: this photo matches employee 'Marwan', but the liveness check shows it is a picture of Marwan (printed photo or a phone/screen showing their photo) - NOT Marwan presenting in person. This is not a real human in front of the camera. Access DENIED."
}
```

As a library (e.g. called from a backend that receives the photo burst
from a mobile app), keep one `ModelBundle` loaded and reuse it per
request instead of reloading models each time:

```python
from mobile_check import ModelBundle, check_access

bundle = ModelBundle.load()

# per check-in attempt:
result = check_access(bundle, frames)   # frames: list of BGR numpy arrays
if result["access_granted"]:
    ...
elif result["is_spoof_of_known_person"]:
    # a KNOWN employee's photo was shown, not the employee in person
    ...
```

`mobile_check.py` reuses the exact same liveness signals as
`detect_webcam.py` (see the table above), just without needing a
persistent camera loop, so the same calibration notes and honesty-about-
limits caveat apply.

## Device detection: "is that face on a phone?"

Every other liveness signal asks *does this face look real?* - texture,
sharpness, moire, motion. A good phone screen under good light can pass
those. So there is now a second, independent question: **is there a
phone / tablet / laptop / monitor / printed photo physically around that
face?** That is geometry, not image quality, so it does not degrade when
the attacker uses a better screen.

`liveness/screen_object.py` answers it three ways:

| Detector | Needs | Catches |
|---|---|---|
| `detect_display_frame()` | nothing extra | the device's own outline - a 4-sided shape enclosing the face, device-like proportions (1.1:1 to 2.6:1), a bezel-dark border, face filling only part of it |
| `screen_panel_cues()` | nothing extra | device held too close for its edges to be in frame: a flat, uniformly lit, brighter-than-skin panel hugging the head, plus rectangular glass glare |
| `CocoDeviceDetector` | `yolov8n.pt` (optional) | the explicit case - a standard COCO model labelling a **cell phone / laptop / tv / book** whose box contains the face |

The COCO model is optional on purpose. `best.pt` was fine-tuned on faces
and knows nothing about phones, so a second small general model (~6 MB)
is the cheapest way to get real device labels. ultralytics downloads it
automatically on a machine with internet; on an offline Pi, copy
`yolov8n.pt` next to `config.py`. If it is missing, the system prints one
note and runs on the two geometric detectors - it never fails to start.

**Device evidence is a veto, not a score.** In `liveness/detector.py`, a
device seen in at least `SCREEN_VETO_RATIO` of a tracked face's recent
frames forces `FAKE` no matter how high the liveness average is - and a
single very confident hit (`SCREEN_INSTANT_VETO_CONFIDENCE`, e.g. COCO
saying "cell phone") refuses immediately. Requiring a *ratio* rather than
a single frame is what keeps it usable: a hand passing through the shot
cannot lock out a real employee, but a phone is still a phone frame after
frame.

Tune it offline, with no models to download:

```bash
python tools/test_screen_detection.py real_person.jpg phone_held_up.jpg print.jpg
python tools/test_screen_detection.py --coco phone_held_up.jpg
```

The false positive that matters most is case 6 in that tool's docstring:
**a real employee who happens to be holding a phone in their hand.** The
face must not be *inside* the phone box for it to count, so this normally
passes - but test it on your own camera before deploying, and raise
`SCREEN_BEZEL_CONFIDENCE` / `SCREEN_PANEL_CONFIDENCE` in `config.py` if
it does not.

## Active liveness: the person must blink and move

Passive checks judge pixels. Pixels improve when the attacker buys a
better phone. So attendance is now gated on something the employee
cannot delegate to a photo: **a real blink, plus head movement that only
a three-dimensional head can produce** (`liveness/active.py`).

### Blink

Uses InsightFace's 106-point landmarks to measure eye height / eye width
- scale-free, so leaning toward the camera doesn't register as a blink.
A state machine counts open -> closed -> open transitions, where the
closure must last between `BLINK_MIN_CLOSED_FRAMES` and
`BLINK_MAX_CLOSED_FRAMES` (a one-frame dip is noise; a five-second
closure is not a blink).

The open-eye baseline is a **75th percentile**, not a median, and that
detail matters: someone is often mid-blink when the camera first sees
them, and a median of those first frames settles near the *closed* value
- after which no blink is ever detected again. That is a silent
fail-open, the worst way for a security check to break, and it is the
kind of bug that never shows up in a demo.

A completely unchanging eye signal for `FROZEN_FRAMES_LIMIT` frames is
reported explicitly as `STILL IMAGE DETECTED`. Real eyes are never that
steady.

### Non-rigid movement

A still face on any flat surface is a plane. However you wave, tilt,
rotate or zoom that plane, one 2D affine transform explains all of it. A
real head is 3D: turn it slightly and the nose swings across the face,
one cheek compresses, the far eye moves toward the nose. So we fit the
best affine transform between an earlier frame's landmarks and the
current ones, and measure the leftover, normalized by how far things
moved - an attacker cannot improve the number by shaking the phone
harder.

Measured with `tools/test_active_liveness.py --simulate`:

| landmark jitter | flat image waved | real head turning |
|---|---|---|
| 0.0 px | 0.000 | 0.366 |
| 0.3 px | 0.019 | 0.364 |
| 0.8 px | 0.052 | 0.387 |
| 1.5 px | 0.089 | 0.435 |

`MOVEMENT_NONRIGID_THRESHOLD` defaults to **0.22**, in the gap. Getting
there took two fixes worth knowing about if you retune it: landmark
jitter is itself non-rigid, so raw frame-to-frame comparison let a waved
photo score 0.26 and pass. The landmarks are now averaged over
`MOVEMENT_SMOOTH_WINDOW` frames, and the score is the **median** of
recent residuals rather than the maximum - a maximum over many frame
pairs is a maximum over noise, and climbs toward 1.0 for anything given
enough frames.

### What this does and does not stop

| Attack | Stopped by |
|---|---|
| Printed photo held up | blink (it never blinks) + non-rigid movement + texture |
| Still photo on a phone | blink + non-rigid movement + device detection |
| Photo waved/tilted to fake movement | non-rigid movement (that is exactly what it measures) |
| **Video replay of a colleague** | **NOT by movement** - a recorded video reproduces genuine 3D motion. Caught by device detection (`screen_object.py`), moire/texture, and challenge mode |

That last row is the honest one. Non-rigid movement is a still-image
defense. If video replay is a real concern rather than a theoretical
one, turn on challenge mode.

### Challenge mode

```bash
python detect_webcam.py --challenge      # or set CHALLENGE_MODE = True
```

The device picks actions at random at the moment of the attempt - "Please
BLINK TWICE", "Please turn your head SLIGHTLY LEFT", "Please NOD your
head" - and gives `CHALLENGE_TIMEOUT_SECONDS` to comply. A video recorded
yesterday cannot know what will be asked today. This is the **only**
mechanism here that genuinely defeats a prepared video. In simulation a
cooperative person clears two challenges in 1.6-2.8 seconds; a static
image never clears them.

Turn challenges accept movement of the required magnitude in **either**
direction, because the sign depends on which eye InsightFace lists first
and whether the camera image is mirrored - a device that scores "left"
backwards and rejects a compliant employee is a far worse failure than
one that accepts either direction and relies on the non-rigid residual
to prove the turn was real.

### Calibrate it

```bash
python tools/test_active_liveness.py --simulate   # no camera or models needed
python tools/test_active_liveness.py --camera     # live numbers, for real tuning
```

The docstring lists the four things to do in front of the camera and what
each should score. Do case (c) - wave a printed photo around - before
trusting the default threshold on your hardware.

### On screen

- `Marwan - Please blink` in amber, with `blinks 0/1  movement 0.04/0.22`
- then `Marwan - LIVE, confirming...` and `Marwan - ATTENDANCE RECORDED`

`--no-active` disables the requirement for testing. Don't ship with it.

## Attendance database

`attendance.py` holds one rule:

> A row in `attendance` means **this named human was physically standing
> in front of the device at this time.**

`record_attendance()` is the only write path into that table, and the
camera loop only reaches it when a face has been recognized **and**
verified live **and** free of device evidence for
`ATTENDANCE_CONFIRM_FRAMES` consecutive frames (~1 second). Any bad frame
resets that counter to zero, so a spoof that scores well for a moment can
never accumulate enough clean frames.

Two SQLite tables in `attendance.db` (no server, works on a Pi):

- **`attendance`** - one row per employee per day: `name`, `date`,
  `check_in_time`, `timestamp`, `last_seen`, `sightings`,
  `liveness_score`, `method`, `evidence_path`. Re-sightings update
  `last_seen` instead of creating a second check-in.
- **`spoof_attempts`** - every refused attempt with its plain-language
  reason and which detector fired. This is an **audit log, not
  attendance**: being in it never marks anyone present.

With `SAVE_EVIDENCE_SNAPSHOTS = True`, a JPEG of each check-in and each
refusal is written to `evidence/`, so every row can be checked against a
picture.

Reporting:

```bash
python tools/attendance_report.py                  # today
python tools/attendance_report.py --date 2026-09-08
python tools/attendance_report.py --csv day.csv
```

The report lists who was present, who was absent, and flags any absentee
somebody *tried* to check in with a photo - which is the case the whole
system exists to surface.

### What the employee sees

- Real person, recognized: `Marwan - LIVE, confirming... (7)` then
  `Marwan - ATTENDANCE RECORDED` in green, and a row in the database.
- Their photo on a phone: `SPOOF: Marwan's photo on a cell phone - NOT
  PRESENT` in red, a `DEVICE: coco:cell phone` tag on the box, a row in
  `spoof_attempts`, and **nothing** in `attendance`. Marwan still shows
  as absent in the report.

New flags: `--no-db` (detect without writing anything), `--no-coco` (skip
the optional device model).

## Honest limits

This is a strong practical barrier, not an unbeatable one. Worth knowing
before you deploy it:

- A **very large, high-quality monitor** filling the frame gives the
  geometric detectors no visible edges; that case falls back on the
  texture/frequency/moire signals.
- A **well-made 3D mask or a curved display** defeats planarity-based
  reasoning. Those are the cases a trained anti-spoofing model (see the
  section below) handles better.
- The thresholds in `config.py` are empirical. Calibrate them on the
  actual camera, mounting height and lighting before trusting the
  numbers, using the two `tools/` scripts.
- For a system that determines pay, keep the evidence snapshots on and
  give employees a way to contest a refusal - `spoof_attempts.reason` is
  written in plain language specifically so it can be shown to a person.

## Running on Raspberry Pi

`cv2.VideoCapture(0)` does **not** reliably work with the official
Raspberry Pi CSI camera module. On Raspberry Pi OS's libcamera-based
camera stack, `cv2.VideoCapture(0)` can *open* successfully
(`isOpened()` returns `True`) but then fail on **every** `.read()` call
with "Could not read frame" - OpenCV's V4L2 backend cannot negotiate a
readable frame from the sensor's ISP pipeline the way libcamera can. If
you saw exactly that error, this was almost certainly the cause. This
project uses **Picamera2** instead, wrapped in `camera_stream.py` so the
rest of the pipeline (YOLO detection, recognition, liveness, active
liveness, attendance) is untouched - everything after
`ret, frame = camera.read()` stays exactly the same as on a laptop
webcam.

**You don't need to remember a flag.** `config.CAMERA_SOURCE = "auto"`
(the default) makes `camera_stream.py` use Picamera2 automatically
whenever the `picamera2` package is installed, and only falls back to a
USB/laptop webcam when it isn't. So on a Pi with `python3-picamera2`
installed, plain `python detect_webcam.py` now uses the CSI camera
correctly with no extra arguments. You can still force a specific camera
if needed:
```bash
python detect_webcam.py --source picamera2   # force the Pi CSI camera
python detect_webcam.py --source 0            # force a USB webcam even on a Pi
```

`camera_stream.py` opens the camera with the same `create_preview_
configuration(main={"size": (w, h), "format": "RGB888"})` call the
engineer's `Picamera2.py` reference script uses, and converts every frame
from RGB (what Picamera2 returns) to BGR (what OpenCV/YOLO/InsightFace
expect) with `cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)` - the same
conversion `Picamera2.py` does. On top of that it adds:
- a configurable warm-up pause (`config.PICAMERA2_WARMUP_SECONDS`) plus a
  few discarded warm-up frames (`config.PICAMERA2_WARMUP_FRAMES`) after
  `start()`, since some camera modules/kernel versions need more than a
  brief pause before the first real frame is ready;
- automatic retries (`config.PICAMERA2_READ_RETRIES`) inside `read()` if
  a single `capture_array()` call fails transiently;
- `config.PICAMERA2_SWAP_RB` to disable the RGB->BGR conversion if your
  specific camera/libcamera version already returns BGR-ordered data
  under the "RGB888" format label (a known quirk on some libcamera
  builds) - you'll know this is needed if faces/skin tones look
  blue-tinted in the preview window.

**Before running, check the camera is actually enabled and detected at
the OS level** (do this once, outside Python):
```bash
# Bookworm-based Pi OS:
rpicam-hello --list-cameras
# Older Bullseye-based Pi OS:
libcamera-hello --list-cameras
```
If no camera is listed:
- Run `sudo raspi-config` -> **Interface Options** -> **Camera** -> enable
  it, then reboot.
- Power off the Pi and reseat the ribbon cable at both ends (CSI camera
  port on the Pi, and the camera module) - the blue/silver contacts face
  the correct direction per your camera model's documentation.
- Make sure nothing else is holding the camera open (another running
  instance of this script, a leftover `libcamera-hello`/`rpicam-hello`
  preview, etc.) - only one process can use the camera at a time.
- If running inside Docker, the container needs `/dev/video*` and
  `/dev/media*` device access; a plain venv does not need this, but does
  need `--system-site-packages` (see install steps below).

**Installing Picamera2 on Raspberry Pi OS (Bookworm and later):**
```bash
sudo apt update
sudo apt install -y python3-picamera2 --no-install-recommends
```
Picamera2 depends on system libcamera bindings, so it's installed via
`apt`, not `pip`. If you use a Python virtual environment for the rest
of this project, create it with `--system-site-packages` so it can see
the apt-installed `picamera2` package:
```bash
python3 -m venv --system-site-packages venv
source venv/bin/activate
pip install -r requirements.txt
```

**Run it:**
```bash
python detect_webcam.py
```
The console will print which backend it actually used, e.g.
`Camera started (PiCamera2Stream). Press Q to quit.` - if you ever see
`(VideoCapture)` on a Pi, that means `picamera2` was not detected as
installed and it fell back to a USB webcam; re-check the install step
above.

**Re-run the calibration test set from above on the Pi** - lighting,
lens, and sensor differences mean the sharpness/frequency reference
constants that work well on your laptop webcam may need adjusting for
the Pi camera.

## Upgrading to a trained anti-spoofing model (optional, later)

If the heuristic system isn't robust enough once you have real users
testing it, the cleanest upgrade is to drop in a small pretrained
face-anti-spoofing ONNX model (e.g. MiniFASNet /
Silent-Face-Anti-Spoofing) and blend its prediction into
`liveness/detector.py`'s `evaluate()` as one more weighted signal (or as
a hard veto). That requires downloading model weights, so it's a next
step for whenever you have internet access on your dev machine - happy
to wire it in when you're ready.
