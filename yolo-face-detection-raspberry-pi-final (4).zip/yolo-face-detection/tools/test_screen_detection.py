"""
Screen / device detection sanity check and calibration tool.

Runs ONLY the display-device detectors from liveness/screen_object.py on
saved images and prints what they found. Uses OpenCV's built-in Haar
cascade to locate the face box, so it needs nothing but opencv-python and
numpy - no YOLO, no InsightFace, no model downloads. That makes it the
fast way to tune SCREEN_BEZEL_CONFIDENCE / SCREEN_PANEL_CONFIDENCE for
your own camera and lighting before running the full pipeline.

Usage:
    python tools/test_screen_detection.py real_person.jpg phone_held_up.jpg print.jpg
    python tools/test_screen_detection.py --coco phone_held_up.jpg   # also run the COCO model

Build a small test set the same way an employee would cheat:
    1. Someone standing in front of the camera            -> expect NO device
    2. A phone showing a colleague's photo, held up       -> expect device
    3. A phone playing a video of a colleague, held up    -> expect device
    4. A printed photo held up                            -> expect device
    5. A tablet / laptop screen showing a face            -> expect device
    6. Someone real, with a phone visible in their hand   -> expect NO device
       (this is the false-positive case that matters most: a real
       employee who happens to be holding a phone must still get in)

If case 1 or 6 reports a device, raise the thresholds in config.py.
If cases 2-5 report none, lower them.
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cv2

from liveness.screen_object import (CocoDeviceDetector, detect_display_frame,
                                    evaluate_screen_evidence, screen_panel_cues)


def find_face_box(image):
    """Largest face via Haar cascade - good enough to place a test box."""
    cascade_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    cascade = cv2.CascadeClassifier(cascade_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
    if len(faces) == 0:
        return None
    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
    return (int(x), int(y), int(x + w), int(y + h))


def analyze(path, coco_detector=None):
    image = cv2.imread(path)
    if image is None:
        print(f"\n{path}\n  Could not read this file.")
        return

    box = find_face_box(image)
    print(f"\n{path}   ({image.shape[1]}x{image.shape[0]})")
    if box is None:
        print("  No face found - can't test device detection without a face box.")
        return
    print(f"  face box: {box}")

    bezel = detect_display_frame(image, box)
    panel = screen_panel_cues(image, box)
    combined = evaluate_screen_evidence(image, box, coco_detector)

    for label, result in (("bezel", bezel), ("panel", panel)):
        status = "DEVICE" if result["detected"] else "clean "
        print(f"  {label:<6} {status}  conf {result['confidence']:.2f}  {result['details']}")

    if coco_detector is not None:
        coco = coco_detector.detect(image, box)
        status = "DEVICE" if coco["detected"] else "clean "
        print(f"  coco   {status}  conf {coco['confidence']:.2f}  {coco['details']}")

    print(f"  VERDICT: {'SPOOF - device detected' if combined['detected'] else 'no device evidence'}")
    if combined["detected"]:
        print(f"           source={combined['source']} conf={combined['confidence']:.2f}")
        print(f"           {combined['reason']}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("images", nargs="+")
    parser.add_argument("--coco", action="store_true",
                        help="Also run the optional COCO cell-phone/laptop/tv detector.")
    args = parser.parse_args()

    detector = None
    if args.coco:
        detector = CocoDeviceDetector()
        if not detector.available:
            print(f"COCO detector unavailable: {detector.load_error}")
            detector = None

    for image_path in args.images:
        analyze(image_path, detector)
    print()
