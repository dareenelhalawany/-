"""
Standalone liveness sanity-check tool.

Runs the single-frame liveness signals (sharpness, texture entropy,
frequency/moire, color) on one or more image files and prints the scores.
This does NOT need YOLO or InsightFace - only opencv-python and numpy -
so it's a fast way to check that the anti-spoofing math itself is
behaving sensibly before wiring it into the full camera pipeline.

Usage:
    python tools/test_liveness_on_images.py real_face.jpg printed_photo.jpg phone_screen.jpg

Tip for building a quick test set:
    1. A close-up selfie taken directly with your laptop webcam -> "real"
    2. A photo of a printed photo of a face (or just a face photo shown on
       paper) -> "print spoof"
    3. A photo of that same face shown on your phone screen -> "screen spoof"
Run all three through this script and compare the frequency/texture
scores - screen and print spoofs should score noticeably lower.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import cv2

from liveness import texture, frequency, color


def analyze(path):
    image = cv2.imread(path)
    if image is None:
        print(f"Could not read: {path}")
        return

    s_sharp = texture.sharpness_score(image)
    s_tex = texture.micro_texture_entropy(image)
    s_freq = frequency.moire_and_grid_penalty(image)
    s_color = color.color_naturalness_score(image)

    combined = 0.25 * s_sharp + 0.35 * s_tex + 0.25 * s_freq + 0.15 * s_color

    print(f"\n{path}")
    print(f"  sharpness_score        : {s_sharp:.3f}")
    print(f"  micro_texture_entropy  : {s_tex:.3f}")
    print(f"  moire_and_grid_penalty : {s_freq:.3f}  (low = screen/print pattern detected)")
    print(f"  color_naturalness      : {s_color:.3f}")
    print(f"  combined (no motion)   : {combined:.3f}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    for image_path in sys.argv[1:]:
        analyze(image_path)
