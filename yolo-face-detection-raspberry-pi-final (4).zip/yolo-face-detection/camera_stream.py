"""
Camera abstraction so detect_webcam.py (and any other script that opens a
camera) does not need an if/else for "webcam vs Raspberry Pi camera"
scattered through the pipeline.

This wraps the engineer's Picamera2.py approach as-is (create_preview_
configuration with format="RGB888", capture_array(), then cv2.cvtColor
RGB2BGR because Picamera2 hands back RGB and OpenCV/YOLO/InsightFace all
expect BGR) inside a class that exposes the same three methods the rest of
this project already calls on a cv2.VideoCapture object:

    camera.isOpened()
    ret, frame = camera.read()
    camera.release()

Nothing downstream of `ret, frame = camera.read()` in detect_webcam.py
changes: this module's job is only to make that line work identically on a
laptop webcam and on the Raspberry Pi CSI camera.

IMPORTANT - why "auto" exists:
On a Raspberry Pi 4 (and other Pi models) running the libcamera camera
stack, the CSI camera is often still visible to OpenCV as /dev/video0, so
cv2.VideoCapture(0).isOpened() can return True - but OpenCV's plain V4L2
backend cannot actually negotiate a readable frame from the sensor's ISP
pipeline the way Picamera2/libcamera can. The result is exactly:
"Camera started" (isOpened() succeeded) immediately followed by
"Could not read frame" (every single .read() call fails). cv2.VideoCapture
is NOT a working path for the Pi CSI camera - only Picamera2 is.
To stop this from happening silently just because someone forgot to pass
--source picamera2, open_camera() defaults to "auto": it uses Picamera2
whenever the picamera2 package is installed, and only falls back to
cv2.VideoCapture(0) when it is not (e.g. on a laptop).
"""

import importlib.util
import time

import cv2

try:
    import config as _config
except ImportError:  # camera_stream.py can still be imported standalone/tested
    _config = None


def _cfg(name, default):
    return getattr(_config, name, default) if _config is not None else default


def picamera2_available():
    """True if the picamera2 package is importable (installed via apt on Pi OS)."""
    try:
        return importlib.util.find_spec("picamera2") is not None
    except (ImportError, ValueError, ModuleNotFoundError):
        # find_spec can raise ValueError in a few edge cases (e.g. a
        # namespace package quirk, or the module already present in
        # sys.modules without a normal loader spec). Never let camera
        # detection crash the whole script over this - fall back to
        # attempting a real import instead.
        try:
            import picamera2  # noqa: F401
            return True
        except ImportError:
            return False


class PiCamera2Stream:
    """Drop-in camera object backed by Picamera2, mirroring Picamera2.py."""

    def __init__(self, width=640, height=480):
        try:
            from picamera2 import Picamera2
        except ImportError as exc:
            raise RuntimeError(
                "picamera2 is not installed. On Raspberry Pi OS install it "
                "with: sudo apt install -y python3-picamera2 "
                "(see README / install instructions)."
            ) from exc

        # Config knobs (config.py), each with a safe default if config.py
        # doesn't define them, so this class still works if imported alone.
        warmup_seconds = _cfg("PICAMERA2_WARMUP_SECONDS", 1.0)
        warmup_frames = _cfg("PICAMERA2_WARMUP_FRAMES", 2)
        self._swap_rb = _cfg("PICAMERA2_SWAP_RB", True)
        self._max_read_retries = _cfg("PICAMERA2_READ_RETRIES", 3)

        self._picam2 = Picamera2()

        # Same configuration the engineer used in Picamera2.py.
        cam_config = self._picam2.create_preview_configuration(
            main={"size": (width, height), "format": "RGB888"}
        )
        self._picam2.configure(cam_config)
        self._picam2.start()

        # Same warm-up pause used in Picamera2.py so the sensor/AE/AWB
        # settle before the first frame is grabbed. Default raised to 1.0s
        # (from the reference script's 0.3s) because some sensors/kernel
        # versions need longer before the pipeline is ready; configurable
        # via config.PICAMERA2_WARMUP_SECONDS.
        time.sleep(warmup_seconds)

        # Discard a few initial frames. On some Pi camera modules / kernel
        # versions, the very first capture_array() call right after start()
        # can throw or return a not-yet-settled frame while AE/AWB/AF are
        # still converging. This is a commonly recommended Picamera2
        # workaround and directly guards against a first-frame failure
        # being mistaken for "the camera doesn't work".
        for _ in range(warmup_frames):
            try:
                self._picam2.capture_array()
            except Exception:
                pass

        self._opened = True

    def isOpened(self):
        return self._opened

    def read(self):
        if not self._opened:
            return False, None

        last_exc = None
        for attempt in range(self._max_read_retries):
            try:
                frame = self._picam2.capture_array()
                break
            except Exception as exc:  # sensor glitch / transient timing issue
                last_exc = exc
                time.sleep(0.05)
        else:
            print(
                f"ERROR: Picamera2 capture failed after "
                f"{self._max_read_retries} attempts: "
                f"{type(last_exc).__name__}: {last_exc}"
            )
            return False, None

        if self._swap_rb:
            # Picamera2 -> RGB, OpenCV (and YOLO/InsightFace downstream) ->
            # BGR. Identical conversion to Picamera2.py. If colors look
            # wrong on your specific camera module (a documented Picamera2
            # quirk on some libcamera versions is that "RGB888" already
            # comes out BGR-ordered), set config.PICAMERA2_SWAP_RB = False.
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        return True, frame

    def set(self, prop_id, value):
        # cv2.VideoCapture.set(...) is called for CAP_PROP_FRAME_WIDTH /
        # HEIGHT in detect_webcam.py. Picamera2's resolution is fixed at
        # configure() time (done in __init__ instead), so this is a no-op
        # kept only so callers don't need a special case.
        return False

    def get(self, prop_id):
        return 0

    def release(self):
        if self._opened:
            try:
                self._picam2.stop()
            except Exception:
                pass
            self._opened = False


# Any of these strings (case-insensitive) passed as --source, or set as
# config.CAMERA_SOURCE, explicitly selects the Raspberry Pi camera.
_PICAMERA2_ALIASES = {"picamera2", "picam2", "pi", "picamera"}


def open_camera(source, width=640, height=480):
    """
    Open `source` and return an object exposing isOpened()/read()/set()/
    release(), regardless of whether it's a laptop/USB webcam, a video
    file, or the Raspberry Pi CSI camera.

    - source == "auto" (the config.py default)  -> Picamera2 if the
      picamera2 package is installed, else cv2.VideoCapture(0). This is
      what makes plain `python detect_webcam.py` work correctly on a Pi
      without anyone needing to remember --source picamera2.
    - source == "picamera2" (or an alias above)  -> always PiCamera2Stream,
      and raises a clear error if picamera2 isn't installed.
    - anything else (int index, video/image path) -> always
      cv2.VideoCapture, even on a Pi (e.g. to force a USB webcam).
    """
    resolved = source

    if isinstance(source, str) and source.strip().lower() == "auto":
        if picamera2_available():
            print("[camera_stream] source='auto' -> picamera2 is installed; "
                  "using the Raspberry Pi CSI camera.")
            resolved = "picamera2"
        else:
            print("[camera_stream] source='auto' -> picamera2 not installed; "
                  "falling back to cv2.VideoCapture(0). If this is a "
                  "Raspberry Pi with a CSI camera, install python3-picamera2 "
                  "(see README) - cv2.VideoCapture does not work with the "
                  "Pi CSI camera.")
            resolved = 0

    if isinstance(resolved, str) and resolved.strip().lower() in _PICAMERA2_ALIASES:
        return PiCamera2Stream(width=width, height=height)

    return cv2.VideoCapture(resolved)
